export interface User {
  _id: string;
  name: string;
  email: string;
  age: number;
  gender: 'male' | 'female' | 'non-binary' | 'other';
  interestedIn: ('male' | 'female' | 'non-binary' | 'everyone')[];
  bio: string;
  photos: string[];
  location: {
    city: string;
    country: string;
    coordinates?: [number, number];
  };
  distanceKm?: number;
  interests: string[];
  isVerified: boolean;
  settings: {
    minAge: number;
    maxAge: number;
    maxDistance: number;
    isVisible: boolean;
    soundEnabled: boolean;
  };
  blockedUsers?: string[];
  lastActive?: string | Date;
  createdAt?: string | Date;
}

export interface MatchPartner {
  _id: string;
  name: string;
  age: number;
  gender: string;
  bio: string;
  photos: string[];
  location: {
    city: string;
    country: string;
  };
  interests: string[];
  isVerified: boolean;
  distanceKm?: number;
}

export interface MatchItem {
  matchId: string;
  matchedAt: string | Date;
  lastInteraction: string | Date;
  partner: MatchPartner;
  lastMessage?: Message;
  unreadCount: number;
}

export interface Message {
  _id: string;
  matchId: string;
  sender: string;
  receiver: string;
  content: string;
  mediaUrl?: string;
  read: boolean;
  readAt?: string | Date;
  createdAt: string | Date;
}

export interface VideoCallState {
  isCalling: boolean;
  isReceivingCall: boolean;
  isCallAccepted: boolean;
  partnerId?: string;
  partnerName?: string;
  partnerPhoto?: string;
  callerSignal?: any;
  isSimulated?: boolean;
}
