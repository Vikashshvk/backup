/**
 * Core pure business logic for Spark Dating App
 */

export interface ProfileInput {
  name?: string;
  bio?: string;
  photos?: string[];
  interests?: string[];
  age?: number;
  isVerified?: boolean;
}

export function calculateProfileCompletion(profile: ProfileInput): number {
  let score = 0;
  if (profile.name && profile.name.trim().length > 0) score += 15;
  if (profile.bio && profile.bio.trim().length >= 20) score += 20;
  else if (profile.bio && profile.bio.trim().length > 0) score += 10;
  if (profile.photos && profile.photos.length >= 1) score += 20;
  if (profile.photos && profile.photos.length >= 3) score += 10;
  if (profile.interests && profile.interests.length >= 3) score += 15;
  else if (profile.interests && profile.interests.length > 0) score += 5;
  if (profile.age && profile.age >= 18) score += 10;
  if (profile.isVerified) score += 10;
  return Math.min(100, score);
}

export function isAgeEligible(age: number | string): boolean {
  const num = typeof age === 'string' ? parseInt(age, 10) : age;
  return !isNaN(num) && num >= 18 && num <= 120;
}

export function matchesGenderPreference(
  candidateGender: string,
  userPreferences: string[]
): boolean {
  if (!userPreferences || userPreferences.length === 0) return true;
  if (userPreferences.includes('everyone')) return true;
  return userPreferences.includes(candidateGender);
}

export function formatDistance(km: number): string {
  if (km <= 1) return 'Less than a mile away';
  if (km < 2) return '1 km away';
  return `${Math.round(km)} km away`;
}

export function formatChatTimestamp(timestamp: Date | string | number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);

  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHour < 24) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  if (diffDay === 1) return 'Yesterday';
  if (diffDay < 7) {
    return date.toLocaleDateString([], { weekday: 'short' });
  }
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}
