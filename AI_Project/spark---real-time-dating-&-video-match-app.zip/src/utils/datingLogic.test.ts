import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateProfileCompletion,
  isAgeEligible,
  matchesGenderPreference,
  formatDistance,
  formatChatTimestamp,
} from './datingLogic.js';

test('calculateProfileCompletion scores full profile at 100%', () => {
  const fullProfile = {
    name: 'Elena',
    bio: 'Looking for adventure, coffee, and great conversations!',
    photos: ['p1.jpg', 'p2.jpg', 'p3.jpg'],
    interests: ['Travel', 'Art', 'Coffee'],
    age: 26,
    isVerified: true,
  };
  assert.equal(calculateProfileCompletion(fullProfile), 100);
});

test('calculateProfileCompletion scores partial profile accurately', () => {
  const partialProfile = {
    name: 'Alex',
    age: 22,
  };
  // 15 (name) + 10 (age) = 25
  assert.equal(calculateProfileCompletion(partialProfile), 25);
});

test('isAgeEligible enforces strict 18+ age constraint', () => {
  assert.equal(isAgeEligible(17), false);
  assert.equal(isAgeEligible(18), true);
  assert.equal(isAgeEligible('25'), true);
  assert.equal(isAgeEligible('invalid'), false);
  assert.equal(isAgeEligible(0), false);
});

test('matchesGenderPreference works for everyone and targeted genders', () => {
  assert.equal(matchesGenderPreference('female', ['everyone']), true);
  assert.equal(matchesGenderPreference('male', ['female', 'non-binary']), false);
  assert.equal(matchesGenderPreference('non-binary', ['female', 'non-binary']), true);
});

test('formatDistance formats distances properly', () => {
  assert.equal(formatDistance(0.5), 'Less than a mile away');
  assert.equal(formatDistance(1.2), '1 km away');
  assert.equal(formatDistance(15.4), '15 km away');
});

test('formatChatTimestamp handles recent timestamps', () => {
  const now = new Date();
  assert.equal(formatChatTimestamp(now), 'Just now');

  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000);
  assert.equal(formatChatTimestamp(fiveMinAgo), '5m ago');
});
