import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { User } from '../types/index.js';
import { calculateProfileCompletion } from '../utils/datingLogic.js';

interface RegisterData {
  name: string;
  email: string;
  password: string;
  age: number;
  gender: string;
  interestedIn: string[];
  bio?: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  completionPercentage: number;
  register: (data: RegisterData) => Promise<{ success: boolean; previewOtp?: string; message?: string }>;
  sendOtp: (email: string, type?: 'register' | 'forgot_password') => Promise<{ success: boolean; previewOtp?: string; message?: string }>;
  verifyOtp: (email: string, otp: string, type?: 'register' | 'forgot_password') => Promise<{ success: boolean; message?: string }>;
  login: (email: string, password: string) => Promise<{ success: boolean; message?: string; requiresVerification?: boolean; email?: string; previewOtp?: string }>;
  demoLogin: () => Promise<{ success: boolean }>;
  logout: () => Promise<void>;
  updateUserContext: (updates: Partial<User>) => void;
  deleteAccount: () => Promise<boolean>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('spark_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchCurrentUser = useCallback(async (authToken: string) => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      const data = await res.json();
      if (data.success && data.user) {
        setUser(data.user);
      } else {
        localStorage.removeItem('spark_token');
        setToken(null);
        setUser(null);
      }
    } catch (err) {
      console.error('Error fetching current user:', err);
      localStorage.removeItem('spark_token');
      setToken(null);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (token) {
      fetchCurrentUser(token);
    } else {
      setIsLoading(false);
    }
  }, [token, fetchCurrentUser]);

  const saveAuthSession = (authToken: string, userData: User) => {
    localStorage.setItem('spark_token', authToken);
    setToken(authToken);
    setUser(userData);
  };

  const register = async (data: RegisterData) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      return json;
    } catch (err: any) {
      return { success: false, message: err.message || 'Registration failed' };
    }
  };

  const sendOtp = async (email: string, type: 'register' | 'forgot_password' = 'register') => {
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, type }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, message: err.message || 'Failed to send OTP' };
    }
  };

  const verifyOtp = async (email: string, otp: string, type: 'register' | 'forgot_password' = 'register') => {
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp, type }),
      });
      const json = await res.json();
      if (json.success && json.token && json.user) {
        saveAuthSession(json.token, json.user);
      }
      return json;
    } catch (err: any) {
      return { success: false, message: err.message || 'Verification failed' };
    }
  };

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const json = await res.json();
      if (json.success && json.token && json.user) {
        saveAuthSession(json.token, json.user);
      }
      return json;
    } catch (err: any) {
      return { success: false, message: err.message || 'Login failed' };
    }
  };

  const demoLogin = async () => {
    try {
      const res = await fetch('/api/auth/demo-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const json = await res.json();
      if (json.success && json.token && json.user) {
        saveAuthSession(json.token, json.user);
        return { success: true };
      }
      return { success: false };
    } catch (err) {
      return { success: false };
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (e) {
      // ignore
    } finally {
      localStorage.removeItem('spark_token');
      setToken(null);
      setUser(null);
    }
  };

  const updateUserContext = (updates: Partial<User>) => {
    setUser((prev) => (prev ? { ...prev, ...updates } : null));
  };

  const refreshProfile = async () => {
    if (token) {
      await fetchCurrentUser(token);
    }
  };

  const deleteAccount = async (): Promise<boolean> => {
    if (!token) return false;
    try {
      const res = await fetch('/api/users/account', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const json = await res.json();
      if (json.success) {
        await logout();
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  };

  const completionPercentage = user ? calculateProfileCompletion(user) : 0;

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user && !!token,
        isLoading,
        completionPercentage,
        register,
        sendOtp,
        verifyOtp,
        login,
        demoLogin,
        logout,
        updateUserContext,
        deleteAccount,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
