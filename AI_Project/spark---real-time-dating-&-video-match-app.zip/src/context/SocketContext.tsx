import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './AuthContext.js';
import { VideoCallState, Message } from '../types/index.js';

interface SocketContextType {
  socket: Socket | null;
  onlineUserIds: string[];
  isUserOnline: (id: string) => boolean;
  callState: VideoCallState;
  incomingCall: {
    from: string;
    name: string;
    callerPhoto?: string;
    signal: any;
  } | null;
  startVideoCall: (partnerId: string, partnerName: string, partnerPhoto?: string) => void;
  acceptIncomingCall: () => void;
  declineIncomingCall: () => void;
  endActiveCall: () => void;
  activeMatchNotification: { matchId: string; partnerName: string; message: Message } | null;
  clearMatchNotification: () => void;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

export function SocketProvider({ children }: { children: React.ReactNode }) {
  const { user, token } = useAuth();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [onlineUserIds, setOnlineUserIds] = useState<string[]>([]);
  const [activeMatchNotification, setActiveMatchNotification] = useState<{ matchId: string; partnerName: string; message: Message } | null>(null);

  const [callState, setCallState] = useState<VideoCallState>({
    isCalling: false,
    isReceivingCall: false,
    isCallAccepted: false,
  });

  const [incomingCall, setIncomingCall] = useState<{
    from: string;
    name: string;
    callerPhoto?: string;
    signal: any;
  } | null>(null);

  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    // Connect to same origin
    const socketClient = io({
      auth: { token: token || '' },
      transports: ['websocket', 'polling'],
      autoConnect: true,
    });

    socketRef.current = socketClient;
    setSocket(socketClient);

    socketClient.on('connect', () => {
      if (user?._id) {
        socketClient.emit('register_user', user._id);
      }
    });

    socketClient.on('online_users_list', (ids: string[]) => {
      setOnlineUserIds(ids);
    });

    socketClient.on('user_online', ({ userId }: { userId: string }) => {
      setOnlineUserIds((prev) => (prev.includes(userId) ? prev : [...prev, userId]));
    });

    socketClient.on('user_offline', ({ userId }: { userId: string }) => {
      setOnlineUserIds((prev) => prev.filter((id) => id !== userId));
    });

    // WebRTC Signaling events
    socketClient.on('incoming_call', (data) => {
      setIncomingCall(data);
      setCallState((prev) => ({
        ...prev,
        isReceivingCall: true,
        partnerId: data.from,
        partnerName: data.name,
        partnerPhoto: data.callerPhoto,
        callerSignal: data.signal,
      }));
    });

    socketClient.on('call_accepted', (data) => {
      setCallState((prev) => ({
        ...prev,
        isCalling: false,
        isCallAccepted: true,
        isSimulated: data.isSimulated,
        partnerName: prev.partnerName || data.calleeName,
        partnerPhoto: prev.partnerPhoto || data.calleePhoto,
      }));
    });

    socketClient.on('call_ended', () => {
      setCallState({
        isCalling: false,
        isReceivingCall: false,
        isCallAccepted: false,
      });
      setIncomingCall(null);
    });

    socketClient.on('call_declined', () => {
      setCallState({
        isCalling: false,
        isReceivingCall: false,
        isCallAccepted: false,
      });
      setIncomingCall(null);
    });

    socketClient.on('unread_message_notification', (data) => {
      setActiveMatchNotification({
        matchId: data.matchId,
        partnerName: data.senderName,
        message: data.message,
      });
    });

    return () => {
      socketClient.disconnect();
    };
  }, [token]);

  // Re-register when user changes
  useEffect(() => {
    if (socket && user?._id) {
      socket.emit('register_user', user._id);
    }
  }, [socket, user?._id]);

  const isUserOnline = (id: string) => {
    if (id.startsWith('user_seed_')) return true; // Seeds are online
    return onlineUserIds.includes(id);
  };

  const startVideoCall = (partnerId: string, partnerName: string, partnerPhoto?: string) => {
    if (!socket || !user) return;
    setCallState({
      isCalling: true,
      isReceivingCall: false,
      isCallAccepted: false,
      partnerId,
      partnerName,
      partnerPhoto,
    });

    socket.emit('call_user', {
      userToCall: partnerId,
      signalData: { type: 'offer', sdp: 'spark_webrtc_offer_signal' },
      from: user._id,
      name: user.name,
      callerPhoto: user.photos?.[0],
    });
  };

  const acceptIncomingCall = () => {
    if (!socket || !incomingCall) return;
    setCallState((prev) => ({
      ...prev,
      isReceivingCall: false,
      isCallAccepted: true,
    }));

    socket.emit('answer_call', {
      signal: { type: 'answer', sdp: 'spark_webrtc_answer_signal' },
      to: incomingCall.from,
    });
  };

  const declineIncomingCall = () => {
    if (!socket || !incomingCall) return;
    socket.emit('decline_call', { to: incomingCall.from });
    setIncomingCall(null);
    setCallState({
      isCalling: false,
      isReceivingCall: false,
      isCallAccepted: false,
    });
  };

  const endActiveCall = () => {
    if (socket && (callState.partnerId || incomingCall?.from)) {
      const targetId = callState.partnerId || incomingCall?.from;
      if (targetId) {
        socket.emit('end_call', { to: targetId });
      }
    }
    setCallState({
      isCalling: false,
      isReceivingCall: false,
      isCallAccepted: false,
    });
    setIncomingCall(null);
  };

  const clearMatchNotification = () => {
    setActiveMatchNotification(null);
  };

  return (
    <SocketContext.Provider
      value={{
        socket,
        onlineUserIds,
        isUserOnline,
        callState,
        incomingCall,
        startVideoCall,
        acceptIncomingCall,
        declineIncomingCall,
        endActiveCall,
        activeMatchNotification,
        clearMatchNotification,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket(): SocketContextType {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
}
