import React, { useState, useRef } from 'react';
import {
  Upload,
  Trash2,
  CheckCircle2,
  Eye,
  Edit3,
  MapPin,
  Sparkles,
  ShieldCheck,
  Plus,
  Save,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { SwipeCard } from '../discovery/SwipeCard.js';

const INTEREST_OPTIONS = [
  'Coffee',
  'Wine Tasting',
  'Hiking',
  'Travel',
  'Photography',
  'Cooking',
  'Fine Dining',
  'Art Galleries',
  'Architecture',
  'Bouldering',
  'Tennis',
  'Running',
  'Tech',
  'Design',
  'Indie Rock',
  'Jazz',
  'Vinyl',
  'Podcasts',
  'Books',
  'Dogs',
  'Cats',
  'Board Games',
  'Yoga',
  'Night Rides',
];

export const ProfileView: React.FC = () => {
  const { user, token, updateUserContext, completionPercentage } = useAuth();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [age, setAge] = useState(user?.age || 24);
  const [city, setCity] = useState(user?.location?.city || 'San Francisco');
  const [interests, setInterests] = useState<string[]>(user?.interests || []);

  if (!user) return null;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !token) return;

    setIsUploading(true);
    setFeedbackMsg(null);

    const formData = new FormData();
    formData.append('photo', file);

    try {
      const res = await fetch('/api/users/photos', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      const data = await res.json();
      if (data.success && data.user) {
        updateUserContext(data.user);
        setFeedbackMsg('Photo added successfully!');
      }
    } catch (err) {
      console.error('Photo upload failed:', err);
      setFeedbackMsg('Failed to upload photo.');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDeletePhoto = async (photoUrl: string) => {
    if (!token) return;
    try {
      const res = await fetch('/api/users/photos', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ photoUrl }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        updateUserContext(data.user);
      }
    } catch (err) {
      console.error('Failed to delete photo:', err);
    }
  };

  const toggleInterest = (tag: string) => {
    if (interests.includes(tag)) {
      setInterests(interests.filter((t) => t !== tag));
    } else {
      if (interests.length < 10) {
        setInterests([...interests, tag]);
      }
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    setIsSaving(true);
    setFeedbackMsg(null);

    try {
      const res = await fetch('/api/users/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name,
          bio,
          age: Number(age),
          interests,
          location: { ...user.location, city },
        }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        updateUserContext(data.user);
        setFeedbackMsg('Profile saved successfully!');
      }
    } catch (err) {
      setFeedbackMsg('Failed to save profile changes.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      {/* Top Controls: Completion & Preview Toggle */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs mb-6">
        <div className="space-y-1.5 w-full sm:w-auto">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-extrabold text-neutral-900 dark:text-neutral-100">
              Profile Strength
            </h2>
            <span className="text-xs font-black text-rose-500 bg-rose-50 dark:bg-rose-950 px-2 py-0.5 rounded-full">
              {completionPercentage}%
            </span>
          </div>

          {/* Progress bar */}
          <div className="w-full sm:w-64 h-2.5 rounded-full bg-neutral-100 dark:bg-neutral-700 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-rose-500 to-amber-500 transition-all duration-500"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>

        <button
          onClick={() => setIsPreviewMode(!isPreviewMode)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer border ${
            isPreviewMode
              ? 'bg-rose-500 text-white border-rose-500 shadow-md'
              : 'bg-neutral-50 dark:bg-neutral-700 border-neutral-200 dark:border-neutral-600 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100'
          }`}
        >
          {isPreviewMode ? <Edit3 className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          <span>{isPreviewMode ? 'Back to Editor' : 'Public Card Preview'}</span>
        </button>
      </div>

      {feedbackMsg && (
        <div className="mb-4 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs font-bold text-emerald-600 dark:text-emerald-400 text-center animate-fade-in">
          {feedbackMsg}
        </div>
      )}

      {/* Mode 1: Public Card Preview */}
      {isPreviewMode ? (
        <div className="max-w-sm mx-auto animate-fade-in">
          <p className="text-xs text-center text-neutral-500 dark:text-neutral-400 mb-3">
            This is exactly how potential matches see your card on Spark:
          </p>
          <SwipeCard
            candidate={{
              _id: user._id,
              name: name || user.name,
              age: Number(age) || user.age,
              bio: bio || user.bio,
              photos: user.photos || [],
              location: { city, country: 'USA' },
              interests,
              isVerified: user.isVerified,
              distanceKm: 2,
            }}
            onSwipeLeft={() => {}}
            onSwipeRight={() => {}}
          />
        </div>
      ) : (
        /* Mode 2: Profile Editor */
        <form onSubmit={handleSaveProfile} className="space-y-6">
          {/* Photo Gallery Grid */}
          <div className="p-6 rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                Profile Photos (Up to 6)
              </h3>
              <p className="text-xs text-neutral-500">
                High-quality photos increase your match rate by up to 300%. First photo is your primary cover.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {(user.photos || []).map((photo, idx) => (
                <div
                  key={idx}
                  className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-neutral-100 dark:bg-neutral-700 group border border-neutral-200 dark:border-neutral-600 shadow-xs"
                >
                  <img src={photo} alt={`Photo ${idx + 1}`} className="w-full h-full object-cover" />
                  {idx === 0 && (
                    <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-rose-500 text-white text-[10px] font-extrabold uppercase">
                      Cover
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => handleDeletePhoto(photo)}
                    aria-label="Delete photo"
                    className="absolute top-2 right-2 p-1.5 rounded-xl bg-black/60 hover:bg-rose-600 text-white opacity-0 group-hover:opacity-100 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              {/* Upload New Photo Box */}
              {(user.photos?.length || 0) < 6 && (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="aspect-[3/4] rounded-2xl border-2 border-dashed border-rose-300 dark:border-rose-900/60 bg-rose-50/50 dark:bg-rose-950/20 hover:bg-rose-100/50 dark:hover:bg-rose-950/40 text-rose-500 flex flex-col items-center justify-center p-4 transition cursor-pointer"
                >
                  <Upload className={`w-6 h-6 mb-1 ${isUploading ? 'animate-bounce' : ''}`} />
                  <span className="text-xs font-bold text-center">
                    {isUploading ? 'Uploading...' : 'Add Photo'}
                  </span>
                </button>
              )}
            </div>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handlePhotoUpload}
              accept="image/*"
              className="hidden"
            />
          </div>

          {/* Bio & Basic Info */}
          <div className="p-6 rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              Basic Details & About You
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100 text-xs sm:text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Age
                </label>
                <input
                  type="number"
                  min={18}
                  max={100}
                  required
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100 text-xs sm:text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  City
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100 text-xs sm:text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300">
                  Bio / Dating Pitch
                </label>
                <span className="text-[11px] text-neutral-400">{bio.length} / 500</span>
              </div>
              <textarea
                rows={4}
                maxLength={500}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Share your passions, favorite weekend plans, and what sparks your interest..."
                className="w-full p-3.5 rounded-2xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100 text-xs sm:text-sm focus:outline-hidden focus:ring-2 focus:ring-rose-500 resize-none leading-relaxed"
              />
            </div>
          </div>

          {/* Interests & Passions Selector */}
          <div className="p-6 rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                  Interests & Lifestyle ({interests.length} / 10)
                </h3>
                <p className="text-xs text-neutral-500">Pick tags that highlight your vibe</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {INTEREST_OPTIONS.map((tag) => {
                const isSelected = interests.includes(tag);
                return (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => toggleInterest(tag)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition cursor-pointer ${
                      isSelected
                        ? 'bg-rose-500 text-white border-rose-500 shadow-xs'
                        : 'bg-neutral-50 dark:bg-neutral-700/60 border-neutral-200 dark:border-neutral-600 text-neutral-700 dark:text-neutral-300 hover:border-neutral-400'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-bold text-sm shadow-lg shadow-rose-500/25 transition cursor-pointer flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Saving Changes...' : 'Save Profile Changes'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
