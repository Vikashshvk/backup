import React from 'react';
import { Heart, Video, MessageCircle, ShieldCheck, Sparkles, ArrowRight, Star, Flame, Check } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';

interface LandingPageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onOpenAuth }) => {
  const { demoLogin } = useAuth();

  return (
    <div className="relative min-h-[calc(100vh-4rem)] flex flex-col justify-between overflow-hidden">
      {/* Background Glow Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-rose-500/15 via-amber-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-2/3 right-10 w-[400px] h-[400px] bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-12 pb-16 lg:pt-16 lg:pb-24 flex-1 flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
        {/* Left Column: Value Prop */}
        <div className="flex-1 text-center lg:text-left space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-100/80 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900/50 text-xs font-bold text-rose-600 dark:text-rose-400">
            <Flame className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
            <span>Next-Generation Dating & Video Platform</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50 leading-[1.15]">
            Where genuine{' '}
            <span className="bg-gradient-to-r from-rose-500 via-rose-400 to-amber-500 bg-clip-text text-transparent">
              sparks
            </span>{' '}
            turn into real connections.
          </h1>

          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 max-w-xl mx-auto lg:mx-0 leading-relaxed">
            Experience smart mutual matchmaking, seamless real-time chat, and crystal-clear 1-on-1 WebRTC video dates. Verified, authentic, and built for people who value real chemistry.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
            <button
              onClick={() => onOpenAuth('register')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-gradient-to-r from-rose-500 via-rose-600 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-extrabold text-base shadow-lg shadow-rose-500/30 transition transform hover:-translate-y-0.5 cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Get Started Free</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              onClick={() => demoLogin()}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700/80 border border-neutral-300/80 dark:border-neutral-700 text-neutral-800 dark:text-neutral-100 font-bold text-base transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Explore Demo Mode</span>
            </button>
          </div>

          {/* Trust Highlights */}
          <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-neutral-500 dark:text-neutral-400 font-medium">
            <div className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-500" />
              <span>Strict 18+ OTP Verification</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-500" />
              <span>End-to-End Realtime Chat</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-500" />
              <span>Peer WebRTC Video</span>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive App Mockup Preview */}
        <div className="flex-1 w-full max-w-sm lg:max-w-md relative">
          <div className="relative mx-auto w-full aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl border-4 border-white/20 dark:border-neutral-800 bg-neutral-900 group">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80"
              alt="Elena Profile Preview"
              className="w-full h-full object-cover group-hover:scale-105 transition duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />

            {/* Live Video Speed Dating Floating Badge */}
            <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/50 backdrop-blur-md border border-white/20 text-white text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <Video className="w-3.5 h-3.5 text-rose-400" />
              <span>HD Video Ready</span>
            </div>

            {/* Profile Info Overlay */}
            <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
              <div className="flex items-center gap-2">
                <h3 className="text-2xl font-extrabold">Elena Rostova, 26</h3>
                <ShieldCheck className="w-5 h-5 text-sky-400" />
              </div>
              <p className="text-xs text-neutral-300 line-clamp-2">
                Sommelier & culinary explorer 🍷 Looking for witty banter, spontaneous road trips, and sunset views.
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {['Wine Tasting', 'Travel', 'Architecture'].map((t) => (
                  <span key={t} className="px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[10px] font-semibold">
                    {t}
                  </span>
                ))}
              </div>

              {/* Floating Action Buttons */}
              <div className="flex items-center justify-center gap-4 pt-4">
                <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-rose-400 shadow-md">
                  <Heart className="w-6 h-6 fill-rose-500 text-rose-500 animate-pulse" />
                </div>
                <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-amber-300 shadow-md">
                  <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Pillar Highlights */}
      <div className="border-t border-neutral-200/60 dark:border-neutral-800 bg-neutral-50/70 dark:bg-neutral-900/40 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-800/80 border border-neutral-200/80 dark:border-neutral-700/60 shadow-xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center font-bold">
                <Heart className="w-5 h-5 fill-rose-500" />
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                Mutual Matchmaking
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Connect only when there is mutual attraction. Say goodbye to unwanted inboxes and spam messages.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-800/80 border border-neutral-200/80 dark:border-neutral-700/60 shadow-xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center font-bold">
                <MessageCircle className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                Real-Time Socket Messaging
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Instant chat delivery with real-time typing indicators, read receipts, and media photo sharing.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-800/80 border border-neutral-200/80 dark:border-neutral-700/60 shadow-xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-violet-500/10 text-violet-500 flex items-center justify-center font-bold">
                <Video className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                WebRTC 1-on-1 Video Calling
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Peer-to-peer audio and video calls. Verify authenticity and have a natural virtual date without exchanging phone numbers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
