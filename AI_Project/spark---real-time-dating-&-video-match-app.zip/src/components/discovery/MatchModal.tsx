import React from 'react';
import { Heart, MessageCircle, Video, X, Sparkles } from 'lucide-react';
import { User, MatchPartner } from '../../types/index.js';

interface MatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  partner: MatchPartner;
  onOpenChat: () => void;
  onStartVideoCall: () => void;
}

export const MatchModal: React.FC<MatchModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  partner,
  onOpenChat,
  onStartVideoCall,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-gradient-to-b from-neutral-900 via-neutral-900 to-black text-white rounded-3xl p-8 text-center border border-rose-500/30 shadow-2xl overflow-hidden">
        {/* Background Sparkles / Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-72 bg-rose-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close match celebration"
          className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Celebration Title */}
        <div className="space-y-1 mb-8 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-500/30 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Mutual Spark Found</span>
          </div>

          <h2 className="text-4xl font-black tracking-tight bg-gradient-to-r from-rose-400 via-rose-300 to-amber-300 bg-clip-text text-transparent italic">
            It's a Match!
          </h2>
          <p className="text-xs text-neutral-300">
            You and <strong className="text-white font-bold">{partner.name}</strong> liked each other.
          </p>
        </div>

        {/* Dual Avatars with Heart Ring */}
        <div className="flex items-center justify-center gap-4 mb-8 relative">
          <div className="relative">
            <img
              src={currentUser.photos?.[0] || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
              alt={currentUser.name}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-rose-500 shadow-xl"
            />
            <span className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-rose-500 text-white shadow-md">
              <Heart className="w-3.5 h-3.5 fill-white" />
            </span>
          </div>

          {/* Central Pulsing Heart Icon */}
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center shadow-lg shadow-rose-500/50 z-10 -mx-4 animate-pulse">
            <Heart className="w-6 h-6 fill-white text-white" />
          </div>

          <div className="relative">
            <img
              src={partner.photos?.[0] || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80'}
              alt={partner.name}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-amber-400 shadow-xl"
            />
            <span className="absolute -bottom-1 -left-1 p-1.5 rounded-full bg-amber-500 text-white shadow-md">
              <Sparkles className="w-3.5 h-3.5 fill-white text-white" />
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 relative z-10">
          <button
            onClick={() => {
              onClose();
              onOpenChat();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-extrabold text-sm shadow-lg shadow-rose-500/30 transition transform hover:-translate-y-0.5 cursor-pointer flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Send a Message to {partner.name}</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onStartVideoCall();
            }}
            className="w-full py-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-sm transition cursor-pointer flex items-center justify-center gap-2"
          >
            <Video className="w-5 h-5 text-rose-400" />
            <span>Start 1-on-1 Video Date</span>
          </button>

          <button
            onClick={onClose}
            className="pt-2 text-xs font-semibold text-neutral-400 hover:text-white transition cursor-pointer"
          >
            Keep Swiping
          </button>
        </div>
      </div>
    </div>
  );
};
