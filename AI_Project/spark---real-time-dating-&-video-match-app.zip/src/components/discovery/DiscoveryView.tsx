import React, { useState, useEffect, useCallback } from 'react';
import { X, Heart, Star, RotateCcw, SlidersHorizontal, LayoutGrid, Layers, RefreshCw, Video } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { SwipeCard } from './SwipeCard.js';
import { MatchModal } from './MatchModal.js';
import { MatchPartner } from '../../types/index.js';

interface DiscoveryViewProps {
  onOpenChatWithMatch: (partner: MatchPartner) => void;
  onStartVideoCallWithMatch: (partner: MatchPartner) => void;
}

export const DiscoveryView: React.FC<DiscoveryViewProps> = ({
  onOpenChatWithMatch,
  onStartVideoCallWithMatch,
}) => {
  const { user, token } = useAuth();

  const [candidates, setCandidates] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [history, setHistory] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [swipeFeedback, setSwipeFeedback] = useState<'like' | 'pass' | 'superlike' | null>(null);

  // Filters
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);
  const [viewMode, setViewMode] = useState<'card' | 'grid'>('card');
  const [genderFilter, setGenderFilter] = useState('all');
  const [maxDistance, setMaxDistance] = useState(50);
  const [minAge, setMinAge] = useState(18);
  const [maxAge, setMaxAge] = useState(38);

  // Mutual Match State
  const [matchedPartner, setMatchedPartner] = useState<MatchPartner | null>(null);

  const fetchDiscovery = useCallback(async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const params = new URLSearchParams({
        gender: genderFilter,
        minAge: String(minAge),
        maxAge: String(maxAge),
        maxDistance: String(maxDistance),
      });

      const res = await fetch(`/api/matches/discovery?${params.toString()}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) {
        setCandidates(data.candidates || []);
        setCurrentIndex(0);
      }
    } catch (err) {
      console.error('Failed to load discovery queue:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token, genderFilter, minAge, maxAge, maxDistance]);

  useEffect(() => {
    fetchDiscovery();
  }, [fetchDiscovery]);

  const handleSwipe = async (action: 'like' | 'pass' | 'superlike') => {
    if (currentIndex >= candidates.length) return;
    const currentCandidate = candidates[currentIndex];

    // Trigger visual feedback
    setSwipeFeedback(action);

    // Save for undo
    setHistory((prev) => [...prev, { candidate: currentCandidate, index: currentIndex }]);

    try {
      const res = await fetch('/api/matches/swipe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          targetUserId: currentCandidate._id,
          action,
        }),
      });

      const data = await res.json();

      setTimeout(() => {
        setSwipeFeedback(null);
        setCurrentIndex((prev) => prev + 1);

        if (data.success && data.isMatch) {
          setMatchedPartner(data.partner || currentCandidate);
        }
      }, 300);
    } catch (err) {
      console.error('Error swiping:', err);
      setSwipeFeedback(null);
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const last = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    setCurrentIndex(last.index);
  };

  const currentCandidate = candidates[currentIndex];
  const hasMore = currentIndex < candidates.length;

  return (
    <div className="max-w-md mx-auto px-4 py-4 sm:py-6 flex flex-col items-center">
      {/* Top Controls Bar */}
      <div className="w-full flex items-center justify-between mb-4">
        <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-2xl border border-neutral-200/80 dark:border-neutral-700">
          <button
            onClick={() => setViewMode('card')}
            aria-label="Card swipe view"
            className={`p-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              viewMode === 'card'
                ? 'bg-white dark:bg-neutral-700 text-rose-500 shadow-xs'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100'
            }`}
          >
            <Layers className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('grid')}
            aria-label="Grid exploration view"
            className={`p-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              viewMode === 'grid'
                ? 'bg-white dark:bg-neutral-700 text-rose-500 shadow-xs'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={() => setShowFilterDrawer(!showFilterDrawer)}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl border text-xs font-bold transition cursor-pointer ${
            showFilterDrawer
              ? 'bg-rose-500 text-white border-rose-500'
              : 'bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-700'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>Filters</span>
        </button>
      </div>

      {/* Filter Options Expandable Panel */}
      {showFilterDrawer && (
        <div className="w-full mb-4 p-4 rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-lg space-y-4 animate-fade-in">
          <div>
            <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Show Me
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { label: 'All', val: 'all' },
                { label: 'Women', val: 'female' },
                { label: 'Men', val: 'male' },
                { label: 'Non-Binary', val: 'non-binary' },
              ].map((g) => (
                <button
                  key={g.val}
                  onClick={() => setGenderFilter(g.val)}
                  className={`py-1.5 text-xs font-bold rounded-xl border transition cursor-pointer ${
                    genderFilter === g.val
                      ? 'bg-rose-500 text-white border-rose-500 shadow-xs'
                      : 'bg-neutral-50 dark:bg-neutral-700/60 border-neutral-200 dark:border-neutral-600 text-neutral-600 dark:text-neutral-300'
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex justify-between text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                <span>Age Range</span>
                <span className="text-rose-500">{minAge} - {maxAge}</span>
              </div>
              <input
                type="range"
                min={18}
                max={50}
                value={maxAge}
                onChange={(e) => setMaxAge(Number(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                <span>Max Distance</span>
                <span className="text-rose-500">{maxDistance} km</span>
              </div>
              <input
                type="range"
                min={5}
                max={100}
                step={5}
                value={maxDistance}
                onChange={(e) => setMaxDistance(Number(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* Main View: Card Swipe Deck or Grid */}
      {isLoading ? (
        <div className="w-full h-[580px] rounded-3xl bg-neutral-100 dark:bg-neutral-800 animate-pulse flex flex-col items-center justify-center space-y-4">
          <div className="w-12 h-12 rounded-full border-4 border-rose-500 border-t-transparent animate-spin" />
          <p className="text-xs font-bold text-neutral-500">Discovering sparks nearby...</p>
        </div>
      ) : viewMode === 'card' ? (
        <div className="w-full relative flex flex-col items-center">
          {hasMore && currentCandidate ? (
            <>
              <SwipeCard
                candidate={currentCandidate}
                onSwipeLeft={() => handleSwipe('pass')}
                onSwipeRight={() => handleSwipe('like')}
                onSuperlike={() => handleSwipe('superlike')}
                swipeFeedback={swipeFeedback}
              />

              {/* Action Buttons Deck */}
              <div className="flex items-center justify-center gap-4 sm:gap-6 mt-6">
                {/* Undo Button */}
                <button
                  onClick={handleUndo}
                  disabled={history.length === 0}
                  aria-label="Undo last swipe"
                  className="w-12 h-12 rounded-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-amber-500 hover:scale-110 active:scale-95 disabled:opacity-30 disabled:scale-100 shadow-md flex items-center justify-center transition cursor-pointer"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>

                {/* Pass (Left Swipe) */}
                <button
                  onClick={() => handleSwipe('pass')}
                  aria-label="Pass on profile"
                  className="w-16 h-16 rounded-full bg-white dark:bg-neutral-800 border-2 border-rose-500/30 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:scale-110 active:scale-95 shadow-lg flex items-center justify-center transition cursor-pointer"
                >
                  <X className="w-8 h-8 stroke-[2.5]" />
                </button>

                {/* Superlike */}
                <button
                  onClick={() => handleSwipe('superlike')}
                  aria-label="Superlike profile"
                  className="w-12 h-12 rounded-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-sky-400 hover:scale-110 active:scale-95 shadow-md flex items-center justify-center transition cursor-pointer"
                >
                  <Star className="w-5 h-5 fill-sky-400 text-sky-400" />
                </button>

                {/* Like (Right Swipe) */}
                <button
                  onClick={() => handleSwipe('like')}
                  aria-label="Like profile"
                  className="w-16 h-16 rounded-full bg-gradient-to-tr from-rose-500 to-amber-500 text-white hover:scale-110 active:scale-95 shadow-xl shadow-rose-500/30 flex items-center justify-center transition cursor-pointer"
                >
                  <Heart className="w-8 h-8 fill-white stroke-[2.5]" />
                </button>
              </div>
            </>
          ) : (
            /* Empty Queue State */
            <div className="w-full h-[520px] rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 flex flex-col items-center justify-center p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-black text-neutral-900 dark:text-neutral-100">
                You've seen all sparks nearby!
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs">
                Check back shortly as new members join, or expand your age and distance filter preferences.
              </p>
              <button
                onClick={fetchDiscovery}
                className="px-5 py-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Refresh Discovery</span>
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Grid Mode Exploration */
        <div className="w-full grid grid-cols-2 gap-3 max-h-[70vh] overflow-y-auto pr-1">
          {candidates.map((c) => (
            <div
              key={c._id}
              className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-neutral-900 shadow-md group"
            >
              <img
                src={c.photos?.[0] || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                alt={c.name}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-2.5 left-2.5 right-2.5 text-white">
                <h4 className="font-bold text-sm truncate">{c.name}, {c.age}</h4>
                <p className="text-[10px] text-neutral-300 truncate">{c.location?.city}</p>
                <div className="flex items-center gap-2 mt-2">
                  <button
                    onClick={() => {
                      onOpenChatWithMatch(c);
                    }}
                    className="flex-1 py-1 rounded-lg bg-rose-500 hover:bg-rose-600 text-[10px] font-bold text-white transition cursor-pointer"
                  >
                    Connect
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Mutual Match Celebration Modal */}
      {matchedPartner && user && (
        <MatchModal
          isOpen={!!matchedPartner}
          onClose={() => setMatchedPartner(null)}
          currentUser={user}
          partner={matchedPartner}
          onOpenChat={() => onOpenChatWithMatch(matchedPartner)}
          onStartVideoCall={() => onStartVideoCallWithMatch(matchedPartner)}
        />
      )}
    </div>
  );
};
