import React, { useState } from 'react';
import { ShieldCheck, MapPin, Sparkles, ChevronLeft, ChevronRight, Info } from 'lucide-react';
import { formatDistance } from '../../utils/datingLogic.js';

interface SwipeCardProps {
  candidate: {
    _id: string;
    name: string;
    age: number;
    bio: string;
    photos: string[];
    location?: { city: string; country: string };
    distanceKm?: number;
    interests?: string[];
    isVerified?: boolean;
  };
  onSwipeLeft: () => void;
  onSwipeRight: () => void;
  onSuperlike?: () => void;
  swipeFeedback?: 'like' | 'pass' | 'superlike' | null;
}

export const SwipeCard: React.FC<SwipeCardProps> = ({
  candidate,
  onSwipeLeft,
  onSwipeRight,
  onSuperlike,
  swipeFeedback,
}) => {
  const [photoIndex, setPhotoIndex] = useState(0);
  const [showFullBio, setShowFullBio] = useState(false);

  const photos =
    candidate.photos && candidate.photos.length > 0
      ? candidate.photos
      : ['https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80'];

  const nextPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPhotoIndex((prev) => (prev + 1) % photos.length);
  };

  const prevPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPhotoIndex((prev) => (prev - 1 + photos.length) % photos.length);
  };

  return (
    <div className="relative w-full h-[580px] sm:h-[620px] rounded-3xl overflow-hidden shadow-2xl select-none bg-neutral-900 border border-neutral-200/40 dark:border-neutral-800 transition-all duration-300">
      {/* Photo carousel */}
      <img
        src={photos[photoIndex]}
        alt={candidate.name}
        className="w-full h-full object-cover pointer-events-none"
      />

      {/* Swipe Feedback Stamp Overlays */}
      {swipeFeedback === 'like' && (
        <div className="absolute top-10 left-8 z-30 px-6 py-2 rounded-2xl border-4 border-emerald-400 bg-emerald-500/20 backdrop-blur-xs text-emerald-400 text-3xl font-black tracking-wider uppercase rotate-[-15deg] shadow-lg animate-bounce">
          LIKE ❤️
        </div>
      )}
      {swipeFeedback === 'pass' && (
        <div className="absolute top-10 right-8 z-30 px-6 py-2 rounded-2xl border-4 border-rose-500 bg-rose-500/20 backdrop-blur-xs text-rose-500 text-3xl font-black tracking-wider uppercase rotate-[15deg] shadow-lg animate-bounce">
          PASS ✕
        </div>
      )}
      {swipeFeedback === 'superlike' && (
        <div className="absolute top-12 left-1/2 -translate-x-1/2 z-30 px-6 py-2 rounded-2xl border-4 border-sky-400 bg-sky-500/20 backdrop-blur-xs text-sky-400 text-2xl font-black tracking-wider uppercase shadow-lg animate-pulse">
          SUPER LIKE ⭐
        </div>
      )}

      {/* Top Progress Segment Bars for Photos */}
      {photos.length > 1 && (
        <div className="absolute top-3 left-4 right-4 z-20 flex gap-1.5">
          {photos.map((_, idx) => (
            <div
              key={idx}
              className={`h-1.5 flex-1 rounded-full transition-all duration-200 ${
                idx === photoIndex ? 'bg-white shadow-xs' : 'bg-white/40'
              }`}
            />
          ))}
        </div>
      )}

      {/* Interactive Photo Tap Navigators */}
      {photos.length > 1 && (
        <>
          <button
            onClick={prevPhoto}
            aria-label="Previous photo"
            className="absolute left-0 top-0 bottom-36 w-1/3 z-10 cursor-pointer focus:outline-hidden"
          />
          <button
            onClick={nextPhoto}
            aria-label="Next photo"
            className="absolute right-0 top-0 bottom-36 w-1/3 z-10 cursor-pointer focus:outline-hidden"
          />
        </>
      )}

      {/* Gradient Dark Shadow for Text Readability */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/35 to-transparent pointer-events-none" />

      {/* Card Content Footer */}
      <div className="absolute bottom-0 inset-x-0 p-6 z-20 text-white space-y-3">
        {/* Name, Age, Verification */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight drop-shadow-md">
              {candidate.name}, <span className="font-normal">{candidate.age}</span>
            </h2>
            {candidate.isVerified && (
              <span title="Verified 18+ Profile">
                <ShieldCheck className="w-6 h-6 text-sky-400 fill-sky-400/20" />
              </span>
            )}
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowFullBio(!showFullBio);
            }}
            aria-label="Toggle bio details"
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md transition cursor-pointer text-neutral-200"
          >
            <Info className="w-5 h-5" />
          </button>
        </div>

        {/* Location & Distance */}
        <div className="flex items-center gap-4 text-xs font-medium text-neutral-300">
          <div className="flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-rose-400" />
            <span>{candidate.location?.city || 'San Francisco'}, {candidate.location?.country || 'USA'}</span>
          </div>

          {candidate.distanceKm !== undefined && (
            <div className="px-2 py-0.5 rounded-full bg-white/10 backdrop-blur-md text-[11px] font-semibold text-rose-300">
              {formatDistance(candidate.distanceKm)}
            </div>
          )}
        </div>

        {/* Bio */}
        {candidate.bio && (
          <p className={`text-xs sm:text-sm text-neutral-200 leading-relaxed drop-shadow-xs ${showFullBio ? '' : 'line-clamp-2'}`}>
            {candidate.bio}
          </p>
        )}

        {/* Interests Badges */}
        {candidate.interests && candidate.interests.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {candidate.interests.slice(0, showFullBio ? undefined : 4).map((interest) => (
              <span
                key={interest}
                className="px-2.5 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold text-white border border-white/10"
              >
                {interest}
              </span>
            ))}
            {!showFullBio && candidate.interests.length > 4 && (
              <span className="px-2 py-1 rounded-full bg-white/10 text-xs font-bold text-neutral-300">
                +{candidate.interests.length - 4}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
