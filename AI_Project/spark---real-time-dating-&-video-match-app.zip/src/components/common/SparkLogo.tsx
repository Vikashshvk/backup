import React from 'react';

interface SparkLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const SparkLogo: React.FC<SparkLogoProps> = ({ size = 'md', showText = true }) => {
  const sizeMap = {
    sm: { box: 'w-7 h-7', svg: 18, text: 'text-lg', sub: 'text-[9px]' },
    md: { box: 'w-9 h-9', svg: 22, text: 'text-xl', sub: 'text-[10px]' },
    lg: { box: 'w-12 h-12', svg: 28, text: 'text-2xl', sub: 'text-xs' },
  };

  const current = sizeMap[size];

  return (
    <div className="flex items-center gap-2.5 select-none">
      {/* Flame Heart Vector SVG */}
      <div
        className={`${current.box} rounded-2xl bg-gradient-to-tr from-rose-600 via-rose-500 to-amber-400 p-0.5 shadow-lg shadow-rose-500/25 flex items-center justify-center`}
      >
        <div className="w-full h-full rounded-[14px] bg-white/10 backdrop-blur-xs flex items-center justify-center">
          <svg
            width={current.svg}
            height={current.svg}
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="text-white drop-shadow-xs"
          >
            {/* Minimalist modern flame + heart hybrid */}
            <path
              d="M12 2C10.5 4.5 10 6.5 10.5 8C8 7 6 9.5 6 12.5C6 16.5 8.7 19.5 12 21.5C15.3 19.5 18 16.5 18 12.5C18 8 13.5 6 13.5 6C13.5 6 14.5 4.5 12 2Z"
              fill="currentColor"
            />
            <path
              d="M12 11C10.5 12.5 10 14 10.5 15C9.5 14.5 9 15.5 9 16.5C9 18.2 10.3 19.5 12 20.5C13.7 19.5 15 18.2 15 16.5C15 14.5 13 13.5 13 13.5C13 13.5 13.5 12.5 12 11Z"
              fill="#FFD200"
            />
          </svg>
        </div>
      </div>

      {showText && (
        <div className="flex flex-col leading-none">
          <span className={`font-extrabold tracking-tight ${current.text} bg-gradient-to-r from-rose-500 via-rose-400 to-amber-500 bg-clip-text text-transparent`}>
            Spark
          </span>
          <span className={`font-semibold tracking-wider uppercase text-neutral-400 dark:text-neutral-400 ${current.sub}`}>
            Match & Connect
          </span>
        </div>
      )}
    </div>
  );
};
