import React from 'react';
import { Flame, MessageCircle, User as UserIcon, Settings, LogOut, ShieldCheck, Sparkles } from 'lucide-react';
import { SparkLogo } from './SparkLogo.js';
import { ThemeToggle } from './ThemeToggle.js';
import { useAuth } from '../../context/AuthContext.js';

interface NavbarProps {
  activeTab: 'discover' | 'chat' | 'profile' | 'settings';
  setActiveTab: (tab: 'discover' | 'chat' | 'profile' | 'settings') => void;
  onOpenAuth: (initialMode?: 'login' | 'register') => void;
  unreadCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAuth,
  unreadCount = 0,
}) => {
  const { user, isAuthenticated, logout, demoLogin, completionPercentage } = useAuth();

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-white/80 dark:bg-neutral-900/80 border-b border-neutral-200/80 dark:border-neutral-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => setActiveTab('discover')}
            className="flex items-center gap-2 cursor-pointer focus:outline-hidden"
          >
            <SparkLogo size="md" />
          </button>

          {/* Tagline / Safety pill */}
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 dark:bg-rose-950/40 border border-rose-200/60 dark:border-rose-900/40 text-[11px] font-semibold text-rose-600 dark:text-rose-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Verified 18+ Matches</span>
          </div>
        </div>

        {/* Center Navigation when Authenticated */}
        {isAuthenticated ? (
          <nav className="flex items-center gap-1 sm:gap-2 p-1 bg-neutral-100 dark:bg-neutral-800/90 rounded-2xl border border-neutral-200/60 dark:border-neutral-700/60">
            <button
              onClick={() => setActiveTab('discover')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'discover'
                  ? 'bg-white dark:bg-neutral-700 text-rose-500 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <Flame className={`w-4 h-4 ${activeTab === 'discover' ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span className="hidden sm:inline">Discover</span>
            </button>

            <button
              onClick={() => setActiveTab('chat')}
              className={`relative flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'chat'
                  ? 'bg-white dark:bg-neutral-700 text-rose-500 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <MessageCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Matches</span>
              {unreadCount > 0 && (
                <span className="inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 text-[10px] font-bold text-white bg-rose-500 rounded-full animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'profile'
                  ? 'bg-white dark:bg-neutral-700 text-rose-500 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <UserIcon className="w-4 h-4" />
              <span className="hidden sm:inline">Profile</span>
              <span className="hidden md:inline-flex text-[10px] px-1.5 py-0.5 rounded-full bg-neutral-200 dark:bg-neutral-600 text-neutral-700 dark:text-neutral-200">
                {completionPercentage}%
              </span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              aria-label="Settings"
              className={`p-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-white dark:bg-neutral-700 text-rose-500 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <Settings className="w-4 h-4" />
            </button>
          </nav>
        ) : (
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-600 dark:text-neutral-300">
            <span className="hover:text-rose-500 transition-colors cursor-pointer" onClick={() => onOpenAuth('login')}>
              How Spark Works
            </span>
            <span className="hover:text-rose-500 transition-colors cursor-pointer" onClick={() => onOpenAuth('login')}>
              Video Speed Dating
            </span>
            <span className="hover:text-rose-500 transition-colors cursor-pointer" onClick={() => onOpenAuth('login')}>
              Safety & Verification
            </span>
          </div>
        )}

        {/* Right Section: Theme Toggle + User Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <ThemeToggle compact />

          {isAuthenticated && user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('profile')}
                className="flex items-center gap-2 p-1 pl-2 pr-3 rounded-full bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200/70 dark:hover:bg-neutral-700 transition cursor-pointer"
              >
                <img
                  src={
                    user.photos?.[0] ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'
                  }
                  alt={user.name}
                  className="w-7 h-7 rounded-full object-cover border border-rose-500"
                />
                <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 hidden sm:inline max-w-[80px] truncate">
                  {user.name}
                </span>
              </button>

              <button
                onClick={logout}
                aria-label="Sign out"
                className="p-2 rounded-xl text-neutral-500 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              {/* Quick 1-click test button */}
              <button
                onClick={demoLogin}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/20 text-xs font-bold transition-all cursor-pointer"
                title="Instant login with demo profile"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>1-Click Demo</span>
              </button>

              <button
                onClick={() => onOpenAuth('login')}
                className="px-3.5 py-1.5 rounded-xl text-sm font-semibold text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition cursor-pointer"
              >
                Log In
              </button>

              <button
                onClick={() => onOpenAuth('register')}
                className="px-4 py-2 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 shadow-md shadow-rose-500/25 transition cursor-pointer"
              >
                Join Spark
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
