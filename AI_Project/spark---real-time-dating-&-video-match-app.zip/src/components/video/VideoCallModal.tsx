import React, { useState, useEffect, useRef } from 'react';
import {
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  SwitchCamera,
  Maximize2,
  Minimize2,
  Sparkles,
  PhoneCall,
  ShieldCheck,
} from 'lucide-react';
import { useSocket } from '../../context/SocketContext.js';
import { useWebRTC } from '../../hooks/useWebRTC.js';

export const VideoCallModal: React.FC = () => {
  const {
    callState,
    incomingCall,
    acceptIncomingCall,
    declineIncomingCall,
    endActiveCall,
  } = useSocket();

  const isCallActive = callState.isCallAccepted;
  const isInitiating = callState.isCalling;
  const isIncoming = callState.isReceivingCall;

  const isOpen = isCallActive || isInitiating || isIncoming;

  const {
    localStream,
    remoteStream,
    isAudioMuted,
    isVideoOff,
    toggleAudio,
    toggleVideo,
    switchCamera,
  } = useWebRTC(isOpen);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);

  const [callDuration, setCallDuration] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Bind media streams to video elements
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  // Call timer
  useEffect(() => {
    let interval: any;
    if (isCallActive) {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(interval);
  }, [isCallActive]);

  if (!isOpen) return null;

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const partnerName = callState.partnerName || incomingCall?.name || 'Your Match';
  const partnerPhoto =
    callState.partnerPhoto ||
    incomingCall?.callerPhoto ||
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md animate-fade-in">
      <div
        className={`relative w-full ${
          isFullscreen ? 'h-full max-w-none' : 'max-w-4xl h-[85vh] sm:h-[80vh]'
        } bg-neutral-950 rounded-3xl overflow-hidden shadow-2xl border border-neutral-800 flex flex-col`}
      >
        {/* Top Header Bar */}
        <div className="absolute top-4 left-4 right-4 z-30 flex items-center justify-between text-white pointer-events-auto">
          <div className="flex items-center gap-3 p-2 px-3.5 rounded-2xl bg-black/50 backdrop-blur-md border border-white/10">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-xs font-bold">{partnerName}</span>
            {isCallActive && (
              <span className="text-xs font-mono font-semibold text-neutral-300">
                • {formatTimer(callDuration)}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-2xl bg-black/50 backdrop-blur-md border border-white/10 text-[11px] font-semibold text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Peer Encrypted</span>
            </div>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              aria-label="Toggle fullscreen video"
              className="p-2.5 rounded-2xl bg-black/50 hover:bg-black/70 backdrop-blur-md border border-white/10 text-neutral-300 hover:text-white transition cursor-pointer"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Video Surface Area */}
        <div className="relative flex-1 bg-neutral-900 flex items-center justify-center overflow-hidden">
          {/* Main Remote Video */}
          {isCallActive ? (
            <div className="relative w-full h-full flex items-center justify-center">
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover opacity-60"
              />
              {/* Partner live visual presentation */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 space-y-4 pointer-events-none">
                <div className="relative">
                  <img
                    src={partnerPhoto}
                    alt={partnerName}
                    className="w-32 h-32 sm:w-40 sm:h-40 rounded-full object-cover border-4 border-rose-500 shadow-2xl"
                  />
                  <span className="absolute -bottom-1 -right-1 p-2 rounded-full bg-emerald-500 text-white shadow-md">
                    <Video className="w-4 h-4" />
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="text-xl font-black text-white">{partnerName}</h4>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-semibold border border-white/10">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>Live WebRTC Audio & Video</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Calling / Ringing State */
            <div className="flex flex-col items-center justify-center text-center p-6 space-y-6 text-white z-20">
              <div className="relative">
                <img
                  src={partnerPhoto}
                  alt={partnerName}
                  className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-rose-500 shadow-2xl"
                />
                <span className="absolute inset-0 rounded-full border-4 border-rose-500/50 animate-ping pointer-events-none" />
              </div>

              <div className="space-y-1.5">
                <h3 className="text-2xl font-black">{partnerName}</h3>
                <p className="text-xs text-neutral-400">
                  {isIncoming
                    ? 'Incoming 1-on-1 WebRTC Video Date...'
                    : 'Calling... Waiting for partner to connect'}
                </p>
              </div>

              {/* Incoming Call Accept / Decline Buttons */}
              {isIncoming ? (
                <div className="flex items-center gap-6 pt-4">
                  <button
                    onClick={declineIncomingCall}
                    className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-xl transition transform hover:scale-105 cursor-pointer"
                    title="Decline"
                  >
                    <PhoneOff className="w-7 h-7" />
                  </button>

                  <button
                    onClick={acceptIncomingCall}
                    className="p-4 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-xl shadow-emerald-500/30 transition transform hover:scale-105 cursor-pointer animate-bounce"
                    title="Accept Video Call"
                  >
                    <Video className="w-7 h-7" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-xs font-semibold text-rose-400 bg-rose-500/10 px-4 py-2 rounded-full border border-rose-500/20">
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Ringing partner...</span>
                </div>
              )}
            </div>
          )}

          {/* Picture-in-Picture Local Camera Preview Tile */}
          <div className="absolute bottom-24 right-4 z-30 w-28 sm:w-40 aspect-[3/4] rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20 bg-neutral-950 group">
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${isVideoOff ? 'hidden' : 'block'}`}
            />
            {isVideoOff && (
              <div className="w-full h-full flex flex-col items-center justify-center bg-neutral-800 text-neutral-400 text-[10px] text-center p-2">
                <VideoOff className="w-6 h-6 mb-1 text-neutral-500" />
                <span>Camera Off</span>
              </div>
            )}
            <span className="absolute bottom-1.5 left-2 text-[10px] font-bold text-white/80 bg-black/60 px-1.5 py-0.5 rounded-md">
              You
            </span>
          </div>
        </div>

        {/* Floating Call Action Controls Bar */}
        <div className="p-4 sm:p-6 bg-black/80 backdrop-blur-md border-t border-neutral-800 flex items-center justify-center gap-4 sm:gap-6 z-30">
          {/* Mute Audio */}
          <button
            onClick={toggleAudio}
            aria-label={isAudioMuted ? 'Unmute microphone' : 'Mute microphone'}
            className={`p-3.5 sm:p-4 rounded-full transition transform hover:scale-105 cursor-pointer ${
              isAudioMuted
                ? 'bg-rose-500 text-white'
                : 'bg-neutral-800 hover:bg-neutral-700 text-white'
            }`}
          >
            {isAudioMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Pause / Disable Video */}
          <button
            onClick={toggleVideo}
            aria-label={isVideoOff ? 'Turn video on' : 'Turn video off'}
            className={`p-3.5 sm:p-4 rounded-full transition transform hover:scale-105 cursor-pointer ${
              isVideoOff
                ? 'bg-rose-500 text-white'
                : 'bg-neutral-800 hover:bg-neutral-700 text-white'
            }`}
          >
            {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
          </button>

          {/* Switch Camera */}
          <button
            onClick={switchCamera}
            aria-label="Switch camera"
            className="p-3.5 sm:p-4 rounded-full bg-neutral-800 hover:bg-neutral-700 text-white transition transform hover:scale-105 cursor-pointer"
          >
            <SwitchCamera className="w-5 h-5" />
          </button>

          {/* End Call / Hangup */}
          <button
            onClick={endActiveCall}
            aria-label="End video call"
            className="p-3.5 sm:p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/30 transition transform hover:scale-105 cursor-pointer"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};
