import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Send,
  Video,
  Image as ImageIcon,
  Check,
  CheckCheck,
  Search,
  MoreVertical,
  ShieldAlert,
  UserX,
  Sparkles,
  ArrowLeft,
  Smile,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { useSocket } from '../../context/SocketContext.js';
import { MatchItem, Message, MatchPartner } from '../../types/index.js';
import { formatChatTimestamp } from '../../utils/datingLogic.js';

interface ChatViewProps {
  initialPartner?: MatchPartner | null;
  onStartVideoCall: (partner: MatchPartner) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  initialPartner,
  onStartVideoCall,
}) => {
  const { user, token } = useAuth();
  const { socket, isUserOnline } = useSocket();

  const [matches, setMatches] = useState<MatchItem[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<MatchItem | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [partnerIsTyping, setPartnerIsTyping] = useState(false);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [showOptionsDropdown, setShowOptionsDropdown] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const typingTimeoutRef = useRef<any>(null);

  // Load user matches
  const fetchMatches = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/matches/matches', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success && data.matches) {
        setMatches(data.matches);

        // If an initial partner was requested, select that match
        if (initialPartner) {
          const matchWithPartner = data.matches.find(
            (m: MatchItem) => m.partner._id === initialPartner._id
          );
          if (matchWithPartner) {
            setSelectedMatch(matchWithPartner);
          }
        } else if (data.matches.length > 0 && !selectedMatch) {
          setSelectedMatch(data.matches[0]);
        }
      }
    } catch (err) {
      console.error('Failed to fetch matches:', err);
    }
  }, [token, initialPartner]);

  useEffect(() => {
    fetchMatches();
  }, [fetchMatches]);

  // Load messages for selected match
  const fetchMessages = useCallback(async (matchId: string) => {
    if (!token || !matchId) return;
    setIsLoadingMessages(true);
    try {
      const res = await fetch(`/api/chat/${matchId}/messages`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) {
        setMessages(data.messages || []);
      }
    } catch (err) {
      console.error('Failed to load messages:', err);
    } finally {
      setIsLoadingMessages(false);
    }
  }, [token]);

  useEffect(() => {
    if (selectedMatch) {
      fetchMessages(selectedMatch.matchId);

      // Join socket match room
      if (socket) {
        socket.emit('join_match_room', selectedMatch.matchId);
      }
    }

    return () => {
      if (socket && selectedMatch) {
        socket.emit('leave_match_room', selectedMatch.matchId);
      }
    };
  }, [selectedMatch, socket, fetchMessages]);

  // Socket listener for new messages & typing
  useEffect(() => {
    if (!socket) return;

    const handleReceiveMessage = (newMsg: Message) => {
      if (selectedMatch && newMsg.matchId === selectedMatch.matchId) {
        setMessages((prev) => {
          if (prev.some((m) => m._id === newMsg._id)) return prev;
          return [...prev, newMsg];
        });
      }
      fetchMatches();
    };

    const handleUserTyping = (data: { matchId: string; userId: string; isTyping: boolean }) => {
      if (selectedMatch && data.matchId === selectedMatch.matchId && data.userId !== user?._id) {
        setPartnerIsTyping(data.isTyping);
      }
    };

    const handleMessagesRead = (data: { matchId: string; readerId: string }) => {
      if (selectedMatch && data.matchId === selectedMatch.matchId) {
        setMessages((prev) =>
          prev.map((m) => (m.sender === user?._id ? { ...m, read: true } : m))
        );
      }
    };

    socket.on('receive_message', handleReceiveMessage);
    socket.on('user_typing', handleUserTyping);
    socket.on('messages_read', handleMessagesRead);

    return () => {
      socket.off('receive_message', handleReceiveMessage);
      socket.off('user_typing', handleUserTyping);
      socket.off('messages_read', handleMessagesRead);
    };
  }, [socket, selectedMatch, user?._id, fetchMatches]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, partnerIsTyping]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !selectedMatch || !token) return;

    const content = inputText.trim();
    setInputText('');

    // Clear typing indicator
    if (socket && selectedMatch) {
      socket.emit('typing_stop', { matchId: selectedMatch.matchId, userId: user?._id });
    }

    try {
      const res = await fetch(`/api/chat/${selectedMatch.matchId}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          receiverId: selectedMatch.partner._id,
          content,
        }),
      });
      const data = await res.json();
      if (data.success && data.message) {
        setMessages((prev) => {
          if (prev.some((m) => m._id === data.message._id)) return prev;
          return [...prev, data.message];
        });
      }
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  const handleTypingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);

    if (socket && selectedMatch && user) {
      socket.emit('typing_start', { matchId: selectedMatch.matchId, userId: user._id });

      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = setTimeout(() => {
        socket.emit('typing_stop', { matchId: selectedMatch.matchId, userId: user._id });
      }, 1500);
    }
  };

  const handleImageSend = () => {
    const sampleImages = [
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    ];
    const randomImg = sampleImages[Math.floor(Math.random() * sampleImages.length)];
    if (!selectedMatch || !token) return;

    fetch(`/api/chat/${selectedMatch.matchId}/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        receiverId: selectedMatch.partner._id,
        content: 'Shared a photo 📷',
        mediaUrl: randomImg,
      }),
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.success && d.message) {
          setMessages((prev) => [...prev, d.message]);
        }
      });
  };

  const handleBlockUser = async () => {
    if (!selectedMatch || !token) return;
    await fetch('/api/users/block', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ targetUserId: selectedMatch.partner._id }),
    });
    setShowOptionsDropdown(false);
    setSelectedMatch(null);
    fetchMatches();
  };

  const filteredMatches = matches.filter((m) =>
    m.partner.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-4 sm:py-6 h-[calc(100vh-5.5rem)] flex gap-4">
      {/* Left Sidebar: Match List */}
      <div
        className={`w-full md:w-80 lg:w-96 flex flex-col bg-white dark:bg-neutral-800 rounded-3xl border border-neutral-200 dark:border-neutral-700 overflow-hidden shadow-xs shrink-0 ${
          selectedMatch ? 'hidden md:flex' : 'flex'
        }`}
      >
        {/* Search header */}
        <div className="p-4 border-b border-neutral-100 dark:border-neutral-700 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <span>Matches & Messages</span>
              <span className="px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-500 text-xs font-bold">
                {matches.length}
              </span>
            </h2>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search your matches..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-neutral-100 dark:bg-neutral-700/60 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
            />
          </div>
        </div>

        {/* Matches list */}
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-100 dark:divide-neutral-700/50">
          {filteredMatches.length > 0 ? (
            filteredMatches.map((item) => {
              const online = isUserOnline(item.partner._id);
              const isSelected = selectedMatch?.matchId === item.matchId;

              return (
                <button
                  key={item.matchId}
                  onClick={() => setSelectedMatch(item)}
                  className={`w-full p-4 flex items-center gap-3.5 text-left transition cursor-pointer ${
                    isSelected
                      ? 'bg-rose-50/80 dark:bg-rose-950/30 border-l-4 border-rose-500'
                      : 'hover:bg-neutral-50 dark:hover:bg-neutral-700/40'
                  }`}
                >
                  {/* Avatar + Online Indicator */}
                  <div className="relative shrink-0">
                    <img
                      src={
                        item.partner.photos?.[0] ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'
                      }
                      alt={item.partner.name}
                      className="w-13 h-13 rounded-2xl object-cover border border-neutral-200 dark:border-neutral-700 shadow-xs"
                    />
                    {online && (
                      <span
                        title="Online now"
                        className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white dark:border-neutral-800"
                      />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 truncate">
                        {item.partner.name}
                      </h4>
                      {item.lastMessage && (
                        <span className="text-[10px] text-neutral-400 font-medium">
                          {formatChatTimestamp(item.lastMessage.createdAt)}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate">
                      {item.lastMessage?.content || 'Matched! Say hello to break the ice.'}
                    </p>
                  </div>

                  {item.unreadCount > 0 && (
                    <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center shrink-0 animate-pulse">
                      {item.unreadCount}
                    </span>
                  )}
                </button>
              );
            })
          ) : (
            <div className="p-8 text-center text-neutral-400 text-xs space-y-2">
              <Sparkles className="w-8 h-8 mx-auto text-neutral-300 dark:text-neutral-600" />
              <p>No matches yet. Head to Discover to swipe and find sparks!</p>
            </div>
          )}
        </div>
      </div>

      {/* Right: Active Chat Window */}
      {selectedMatch ? (
        <div className="flex-1 flex flex-col bg-white dark:bg-neutral-800 rounded-3xl border border-neutral-200 dark:border-neutral-700 overflow-hidden shadow-xs">
          {/* Chat Header */}
          <div className="p-4 border-b border-neutral-100 dark:border-neutral-700 flex items-center justify-between bg-neutral-50/50 dark:bg-neutral-800/50">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSelectedMatch(null)}
                aria-label="Back to matches list"
                className="md:hidden p-2 text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-xl"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div className="relative">
                <img
                  src={
                    selectedMatch.partner.photos?.[0] ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'
                  }
                  alt={selectedMatch.partner.name}
                  className="w-10 h-10 rounded-xl object-cover border border-rose-500/40"
                />
                {isUserOnline(selectedMatch.partner._id) && (
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white dark:border-neutral-800" />
                )}
              </div>

              <div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                  {selectedMatch.partner.name}, {selectedMatch.partner.age}
                </h3>
                <span className="text-[11px] font-medium text-neutral-500 dark:text-neutral-400">
                  {isUserOnline(selectedMatch.partner._id) ? (
                    <span className="text-emerald-500 font-semibold">Active now</span>
                  ) : (
                    'Offline'
                  )}
                </span>
              </div>
            </div>

            {/* Actions: Start Video Call + Dropdown */}
            <div className="flex items-center gap-2 relative">
              <button
                onClick={() => onStartVideoCall(selectedMatch.partner)}
                aria-label="Start WebRTC Video Date"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-bold text-xs shadow-md shadow-rose-500/20 transition cursor-pointer"
              >
                <Video className="w-4 h-4" />
                <span className="hidden sm:inline">Video Date</span>
              </button>

              <button
                onClick={() => setShowOptionsDropdown(!showOptionsDropdown)}
                aria-label="Chat options"
                className="p-2 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-700 transition cursor-pointer"
              >
                <MoreVertical className="w-5 h-5" />
              </button>

              {/* Options Dropdown */}
              {showOptionsDropdown && (
                <div className="absolute right-0 top-12 w-48 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 shadow-xl p-1.5 z-30 text-xs">
                  <button
                    onClick={handleBlockUser}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 cursor-pointer font-medium"
                  >
                    <UserX className="w-4 h-4 text-amber-500" />
                    <span>Block {selectedMatch.partner.name}</span>
                  </button>

                  <button
                    onClick={() => {
                      alert('Thank you. A safety report has been logged.');
                      setShowOptionsDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer font-medium"
                  >
                    <ShieldAlert className="w-4 h-4 text-rose-500" />
                    <span>Report User</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
            {isLoadingMessages ? (
              <div className="h-full flex items-center justify-center">
                <div className="w-8 h-8 rounded-full border-2 border-rose-500 border-t-transparent animate-spin" />
              </div>
            ) : messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2">
                <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                  You matched with {selectedMatch.partner.name}!
                </h4>
                <p className="text-xs text-neutral-400 max-w-xs">
                  Say something nice or propose a 5-minute video chat to break the ice.
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.sender === user?._id;

                return (
                  <div
                    key={msg._id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[78%] sm:max-w-md px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                        isMe
                          ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-white rounded-br-xs shadow-xs'
                          : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100 rounded-bl-xs'
                      }`}
                    >
                      {msg.mediaUrl && (
                        <img
                          src={msg.mediaUrl}
                          alt="Shared media"
                          className="rounded-xl mb-2 max-h-56 object-cover shadow-xs"
                        />
                      )}
                      <p>{msg.content}</p>
                    </div>

                    {/* Metadata: Time + Read Receipt */}
                    <div className="flex items-center gap-1 mt-1 text-[10px] text-neutral-400 px-1">
                      <span>{formatChatTimestamp(msg.createdAt)}</span>
                      {isMe && (
                        <span>
                          {msg.read ? (
                            <CheckCheck className="w-3.5 h-3.5 text-sky-400 inline" />
                          ) : (
                            <Check className="w-3.5 h-3.5 text-neutral-400 inline" />
                          )}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            {/* Typing Indicator */}
            {partnerIsTyping && (
              <div className="flex items-center gap-2 p-2 px-3 rounded-2xl bg-neutral-100 dark:bg-neutral-700 max-w-[140px] animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce" />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce delay-100" />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce delay-200" />
                <span className="text-[11px] text-neutral-500 dark:text-neutral-300 ml-1">typing...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input Field */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 border-t border-neutral-100 dark:border-neutral-700 flex items-center gap-2 bg-neutral-50/50 dark:bg-neutral-800/50"
          >
            <button
              type="button"
              onClick={handleImageSend}
              aria-label="Send image"
              className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 rounded-xl hover:bg-neutral-200/50 dark:hover:bg-neutral-700 transition cursor-pointer"
            >
              <ImageIcon className="w-5 h-5" />
            </button>

            <input
              type="text"
              placeholder={`Message ${selectedMatch.partner.name}...`}
              value={inputText}
              onChange={handleTypingChange}
              className="flex-1 px-4 py-2.5 rounded-2xl bg-white dark:bg-neutral-700 border border-neutral-200 dark:border-neutral-600 text-xs sm:text-sm text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              aria-label="Send message"
              className="p-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 disabled:opacity-40 text-white shadow-md shadow-rose-500/20 transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      ) : (
        /* Empty State */
        <div className="hidden md:flex flex-1 items-center justify-center p-8 bg-white dark:bg-neutral-800 rounded-3xl border border-neutral-200 dark:border-neutral-700 text-center text-neutral-400 space-y-2">
          <div>
            <Sparkles className="w-10 h-10 mx-auto text-neutral-300 dark:text-neutral-600 mb-2" />
            <h4 className="text-sm font-bold text-neutral-700 dark:text-neutral-200">
              Select a conversation
            </h4>
            <p className="text-xs">
              Chat with your matches or propose a spontaneous 1-on-1 video date.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
