import React, { useState } from 'react';
import {
  Sliders,
  Shield,
  Eye,
  Trash2,
  Volume2,
  Moon,
  Sun,
  Laptop,
  AlertTriangle,
  UserX,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { useTheme } from '../../context/ThemeContext.js';

export const SettingsView: React.FC = () => {
  const { user, token, updateUserContext, deleteAccount } = useAuth();
  const { theme, setTheme } = useTheme();

  const [minAge, setMinAge] = useState(user?.settings?.minAge || 18);
  const [maxAge, setMaxAge] = useState(user?.settings?.maxAge || 38);
  const [maxDistance, setMaxDistance] = useState(user?.settings?.maxDistance || 50);
  const [isVisible, setIsVisible] = useState(user?.settings?.isVisible !== false);
  const [soundEnabled, setSoundEnabled] = useState(user?.settings?.soundEnabled !== false);

  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  if (!user) return null;

  const handleSaveSettings = async () => {
    if (!token) return;
    setIsSaving(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/users/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          minAge,
          maxAge,
          maxDistance,
          isVisible,
          soundEnabled,
        }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        updateUserContext(data.user);
        setFeedback('Discovery preferences saved!');
      }
    } catch (e) {
      setFeedback('Failed to update settings.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAccountConfirm = async () => {
    await deleteAccount();
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-neutral-900 dark:text-neutral-100">
            Account & Discovery Settings
          </h2>
          <p className="text-xs text-neutral-500">Manage your matching criteria and app preferences</p>
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs font-bold text-emerald-600 dark:text-emerald-400 text-center animate-fade-in">
          {feedback}
        </div>
      )}

      {/* Discovery Preferences */}
      <div className="p-6 rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-5">
        <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-rose-500" />
          <span>Discovery Preferences</span>
        </h3>

        {/* Max Distance Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-bold text-neutral-700 dark:text-neutral-300">
            <span>Maximum Distance</span>
            <span className="text-rose-500">{maxDistance} km</span>
          </div>
          <input
            type="range"
            min={5}
            max={100}
            step={5}
            value={maxDistance}
            onChange={(e) => setMaxDistance(Number(e.target.value))}
            className="w-full accent-rose-500 cursor-pointer"
          />
          <p className="text-[11px] text-neutral-400">Only see people within this radius</p>
        </div>

        {/* Age Range Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-bold text-neutral-700 dark:text-neutral-300">
            <span>Age Range</span>
            <span className="text-rose-500">{minAge} - {maxAge} years old</span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-[10px] text-neutral-400">Min Age</span>
              <input
                type="number"
                min={18}
                max={maxAge}
                value={minAge}
                onChange={(e) => setMinAge(Number(e.target.value))}
                className="w-full mt-1 px-3 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-700 text-xs text-neutral-900 dark:text-neutral-100"
              />
            </div>
            <div>
              <span className="text-[10px] text-neutral-400">Max Age</span>
              <input
                type="number"
                min={minAge}
                max={70}
                value={maxAge}
                onChange={(e) => setMaxAge(Number(e.target.value))}
                className="w-full mt-1 px-3 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-700 text-xs text-neutral-900 dark:text-neutral-100"
              />
            </div>
          </div>
        </div>

        {/* Visibility Toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-neutral-100 dark:border-neutral-700">
          <div>
            <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
              Profile Visibility
            </span>
            <p className="text-[11px] text-neutral-400">
              Turn off to pause being shown in Discovery swipe decks
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsVisible(!isVisible)}
            className={`w-12 h-6 rounded-full transition-colors cursor-pointer relative p-0.5 ${
              isVisible ? 'bg-rose-500' : 'bg-neutral-300 dark:bg-neutral-600'
            }`}
          >
            <span
              className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                isVisible ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Sound Effects Toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-neutral-100 dark:border-neutral-700">
          <div>
            <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
              Match Sound Effects
            </span>
            <p className="text-[11px] text-neutral-400">Play chimes on mutual matches and messages</p>
          </div>
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`w-12 h-6 rounded-full transition-colors cursor-pointer relative p-0.5 ${
              soundEnabled ? 'bg-rose-500' : 'bg-neutral-300 dark:bg-neutral-600'
            }`}
          >
            <span
              className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                soundEnabled ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        <button
          onClick={handleSaveSettings}
          disabled={isSaving}
          className="w-full py-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs shadow-md transition cursor-pointer"
        >
          {isSaving ? 'Saving...' : 'Apply Discovery Settings'}
        </button>
      </div>

      {/* Global Theme Settings */}
      <div className="p-6 rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
          App Appearance & Theme
        </h3>

        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => setTheme('light')}
            className={`p-3.5 rounded-2xl border text-center transition cursor-pointer ${
              theme === 'light'
                ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-600 dark:text-rose-400 font-bold'
                : 'bg-neutral-50 dark:bg-neutral-700/50 border-neutral-200 dark:border-neutral-600 text-neutral-700 dark:text-neutral-300'
            }`}
          >
            <Sun className="w-5 h-5 mx-auto mb-1 text-amber-500" />
            <span className="text-xs">Light</span>
          </button>

          <button
            onClick={() => setTheme('dark')}
            className={`p-3.5 rounded-2xl border text-center transition cursor-pointer ${
              theme === 'dark'
                ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-600 dark:text-rose-400 font-bold'
                : 'bg-neutral-50 dark:bg-neutral-700/50 border-neutral-200 dark:border-neutral-600 text-neutral-700 dark:text-neutral-300'
            }`}
          >
            <Moon className="w-5 h-5 mx-auto mb-1 text-rose-400" />
            <span className="text-xs">Dark</span>
          </button>

          <button
            onClick={() => setTheme('system')}
            className={`p-3.5 rounded-2xl border text-center transition cursor-pointer ${
              theme === 'system'
                ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-600 dark:text-rose-400 font-bold'
                : 'bg-neutral-50 dark:bg-neutral-700/50 border-neutral-200 dark:border-neutral-600 text-neutral-700 dark:text-neutral-300'
            }`}
          >
            <Laptop className="w-5 h-5 mx-auto mb-1 text-neutral-400" />
            <span className="text-xs">System</span>
          </button>
        </div>
      </div>

      {/* Safety & Danger Zone */}
      <div className="p-6 rounded-3xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/60 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-rose-600 dark:text-rose-400 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          <span>Danger Zone</span>
        </h3>
        <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
          Deleting your account is permanent. It cascades and cleans up all your uploaded photos, mutual matches, chat messages, and discovery profile.
        </p>

        <button
          onClick={() => setShowDeleteModal(true)}
          className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-2"
        >
          <Trash2 className="w-4 h-4" />
          <span>Delete Account</span>
        </button>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-neutral-900 p-6 border border-neutral-200 dark:border-neutral-800 shadow-2xl text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-500 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <h4 className="text-base font-extrabold text-neutral-900 dark:text-neutral-100">
              Permanently Delete Account?
            </h4>
            <p className="text-xs text-neutral-500">
              All your matches, messages, and uploaded photos will be permanently erased immediately. This cannot be undone.
            </p>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 text-xs font-bold text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteAccountConfirm}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md transition cursor-pointer"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
