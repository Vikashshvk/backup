import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext.js';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { SocketProvider, useSocket } from './context/SocketContext.js';
import { Navbar } from './components/common/Navbar.js';
import { LandingPage } from './components/landing/LandingPage.js';
import { AuthModal } from './components/auth/AuthModal.js';
import { DiscoveryView } from './components/discovery/DiscoveryView.js';
import { ChatView } from './components/chat/ChatView.js';
import { ProfileView } from './components/profile/ProfileView.js';
import { SettingsView } from './components/settings/SettingsView.js';
import { VideoCallModal } from './components/video/VideoCallModal.js';
import { MatchPartner } from './types/index.js';

function AppContent() {
  const { isAuthenticated, isLoading } = useAuth();
  const { startVideoCall, activeMatchNotification, clearMatchNotification } = useSocket();

  const [activeTab, setActiveTab] = useState<'discover' | 'chat' | 'profile' | 'settings'>('discover');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [chatInitialPartner, setChatInitialPartner] = useState<MatchPartner | null>(null);

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleOpenChatWithMatch = (partner: MatchPartner) => {
    setChatInitialPartner(partner);
    setActiveTab('chat');
  };

  const handleStartVideoCallWithMatch = (partner: MatchPartner) => {
    startVideoCall(partner._id, partner.name, partner.photos?.[0]);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-neutral-900 flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 rounded-full border-4 border-rose-500 border-t-transparent animate-spin" />
        <div className="text-white text-sm font-bold tracking-wider uppercase">Loading Spark...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-50 font-sans transition-colors selection:bg-rose-500 selection:text-white flex flex-col">
      {/* Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuth={handleOpenAuth}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {!isAuthenticated ? (
          <LandingPage onOpenAuth={handleOpenAuth} />
        ) : (
          <>
            {activeTab === 'discover' && (
              <DiscoveryView
                onOpenChatWithMatch={handleOpenChatWithMatch}
                onStartVideoCallWithMatch={handleStartVideoCallWithMatch}
              />
            )}
            {activeTab === 'chat' && (
              <ChatView
                initialPartner={chatInitialPartner}
                onStartVideoCall={handleStartVideoCallWithMatch}
              />
            )}
            {activeTab === 'profile' && <ProfileView />}
            {activeTab === 'settings' && <SettingsView />}
          </>
        )}
      </main>

      {/* Global Modals */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalMode}
      />

      <VideoCallModal />

      {/* Real-time incoming message notification toast */}
      {activeMatchNotification && activeTab !== 'chat' && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-white dark:bg-neutral-800 border border-rose-500/30 shadow-2xl flex items-center gap-3 animate-bounce">
          <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
          <div className="text-xs">
            <span className="font-bold text-neutral-900 dark:text-neutral-100">
              {activeMatchNotification.partnerName}
            </span>
            <p className="text-neutral-500 truncate max-w-xs">{activeMatchNotification.message.content}</p>
          </div>
          <button
            onClick={() => {
              clearMatchNotification();
              setActiveTab('chat');
            }}
            className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs cursor-pointer"
          >
            Reply
          </button>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <SocketProvider>
          <AppContent />
        </SocketProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
