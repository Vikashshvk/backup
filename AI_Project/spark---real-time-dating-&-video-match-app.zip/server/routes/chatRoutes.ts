import { Router } from 'express';
import {
  getMatchMessages,
  sendMessage,
  markAsRead,
} from '../controllers/chatController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);

router.get('/:matchId/messages', getMatchMessages);
router.post('/:matchId/messages', sendMessage);
router.put('/:matchId/read', markAsRead);

export default router;
