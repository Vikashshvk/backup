import { Router } from 'express';
import {
  register,
  sendOtp,
  verifyOtpHandler,
  login,
  forgotPassword,
  resetPassword,
  demoLogin,
  getMe,
  logout,
} from '../controllers/authController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

router.post('/register', register);
router.post('/send-otp', sendOtp);
router.post('/verify-otp', verifyOtpHandler);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);
router.post('/demo-login', demoLogin);
router.get('/me', authenticateToken, getMe);
router.post('/logout', logout);

export default router;
