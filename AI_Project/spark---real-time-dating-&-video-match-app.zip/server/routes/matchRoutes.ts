import { Router } from 'express';
import {
  getDiscovery,
  handleSwipe,
  getMatchesList,
} from '../controllers/matchController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);

router.get('/discovery', getDiscovery);
router.post('/swipe', handleSwipe);
router.get('/matches', getMatchesList);

export default router;
