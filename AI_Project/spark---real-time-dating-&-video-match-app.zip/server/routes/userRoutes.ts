import { Router } from 'express';
import {
  getProfile,
  updateProfile,
  uploadPhoto,
  deletePhoto,
  updateSettings,
  blockUser,
  reportUser,
  deleteAccount,
} from '../controllers/userController.js';
import { authenticateToken } from '../middleware/auth.js';
import { uploadMiddleware } from '../middleware/upload.js';

const router = Router();

router.use(authenticateToken);

router.get('/profile', getProfile);
router.put('/profile', updateProfile);
router.post('/photos', uploadMiddleware.single('photo'), uploadPhoto);
router.delete('/photos', deletePhoto);
router.put('/settings', updateSettings);
router.post('/block', blockUser);
router.post('/report', reportUser);
router.delete('/account', deleteAccount);

export default router;
