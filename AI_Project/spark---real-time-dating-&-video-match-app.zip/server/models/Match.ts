import mongoose, { Schema, Document } from 'mongoose';

export interface IMatch extends Document {
  users: mongoose.Types.ObjectId[];
  likedBy: mongoose.Types.ObjectId[];
  status: 'pending' | 'matched' | 'passed';
  lastInteraction: Date;
  matchedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export const MatchSchema = new Schema<IMatch>(
  {
    users: [{ type: Schema.Types.ObjectId, ref: 'User', required: true }],
    likedBy: [{ type: Schema.Types.ObjectId, ref: 'User', default: [] }],
    status: {
      type: String,
      enum: ['pending', 'matched', 'passed'],
      default: 'pending',
    },
    lastInteraction: { type: Date, default: Date.now },
    matchedAt: { type: Date },
  },
  { timestamps: true }
);

// Compound index to quickly find matches between two users
MatchSchema.index({ users: 1 });

export const MatchModel = mongoose.models.Match || mongoose.model<IMatch>('Match', MatchSchema);
