import mongoose, { Schema, Document } from 'mongoose';

export interface IUser extends Document {
  name: string;
  email: string;
  passwordHash: string;
  age: number;
  gender: 'male' | 'female' | 'non-binary' | 'other';
  interestedIn: ('male' | 'female' | 'non-binary' | 'everyone')[];
  bio: string;
  photos: string[];
  location: {
    city: string;
    country: string;
    coordinates?: [number, number];
  };
  interests: string[];
  isVerified: boolean;
  settings: {
    minAge: number;
    maxAge: number;
    maxDistance: number;
    isVisible: boolean;
    soundEnabled: boolean;
  };
  blockedUsers: mongoose.Types.ObjectId[];
  reportedUsers: {
    userId: mongoose.Types.ObjectId;
    reason: string;
    date: Date;
  }[];
  lastActive: Date;
  createdAt: Date;
  updatedAt: Date;
}

export const UserSchema = new Schema<IUser>(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    age: { type: Number, required: true, min: 18 },
    gender: {
      type: String,
      enum: ['male', 'female', 'non-binary', 'other'],
      default: 'female',
    },
    interestedIn: {
      type: [String],
      enum: ['male', 'female', 'non-binary', 'everyone'],
      default: ['everyone'],
    },
    bio: { type: String, default: '' },
    photos: { type: [String], default: [] },
    location: {
      city: { type: String, default: 'San Francisco' },
      country: { type: String, default: 'USA' },
      coordinates: { type: [Number], default: [-122.4194, 37.7749] },
    },
    interests: { type: [String], default: [] },
    isVerified: { type: Boolean, default: false },
    settings: {
      minAge: { type: Number, default: 18 },
      maxAge: { type: Number, default: 50 },
      maxDistance: { type: Number, default: 50 },
      isVisible: { type: Boolean, default: true },
      soundEnabled: { type: Boolean, default: true },
    },
    blockedUsers: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    reportedUsers: [
      {
        userId: { type: Schema.Types.ObjectId, ref: 'User' },
        reason: { type: String, required: true },
        date: { type: Date, default: Date.now },
      },
    ],
    lastActive: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export const UserModel = mongoose.models.User || mongoose.model<IUser>('User', UserSchema);
