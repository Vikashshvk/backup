import mongoose, { Schema, Document } from 'mongoose';

export interface IOTP extends Document {
  email: string;
  otp: string;
  type: 'register' | 'forgot_password';
  expiresAt: Date;
  createdAt: Date;
}

export const OTPSchema = new Schema<IOTP>(
  {
    email: { type: String, required: true, lowercase: true, trim: true, index: true },
    otp: { type: String, required: true },
    type: { type: String, enum: ['register', 'forgot_password'], default: 'register' },
    expiresAt: { type: Date, required: true, expires: 600 }, // Expires in 10 minutes
  },
  { timestamps: true }
);

export const OTPModel = mongoose.models.OTP || mongoose.model<IOTP>('OTP', OTPSchema);
