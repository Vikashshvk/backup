import nodemailer from 'nodemailer';

interface SendOtpOptions {
  email: string;
  name?: string;
  otp: string;
  type: 'register' | 'forgot_password';
}

// In-memory debug buffer of latest OTPs for local dev & testing
const latestOtpStore = new Map<string, { otp: string; type: string; timestamp: number }>();

export function getLatestDevOtp(email: string): string | null {
  const item = latestOtpStore.get(email.toLowerCase().trim());
  if (item && Date.now() - item.timestamp < 10 * 60 * 1000) {
    return item.otp;
  }
  return null;
}

export async function sendOtpEmail(options: SendOtpOptions): Promise<{ success: boolean; previewCode?: string }> {
  const { email, name = 'there', otp, type } = options;
  const normalizedEmail = email.toLowerCase().trim();

  // Save for local testing convenience
  latestOtpStore.set(normalizedEmail, {
    otp,
    type,
    timestamp: Date.now(),
  });

  const subject =
    type === 'register'
      ? `Verify your email for Spark - Your Code: ${otp}`
      : `Reset your Spark password - Your Code: ${otp}`;

  const htmlContent = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 24px; border: 1px solid #e5e7eb; border-radius: 12px; background-color: #ffffff;">
      <div style="text-align: center; margin-bottom: 24px;">
        <div style="display: inline-block; background: linear-gradient(135deg, #FF4B4B 0%, #FF8A00 100%); width: 48px; height: 48px; border-radius: 12px; line-height: 48px; font-size: 24px; color: white;">
          🔥
        </div>
        <h1 style="color: #111827; font-size: 24px; margin: 12px 0 4px; font-weight: 800;">Spark Dating</h1>
        <p style="color: #6b7280; font-size: 14px; margin: 0;">Connect genuinely. Meet authentically.</p>
      </div>

      <div style="background-color: #f9fafb; border-radius: 8px; padding: 20px; text-align: center; margin-bottom: 24px;">
        <p style="color: #374151; font-size: 15px; margin-top: 0;">Hello ${name},</p>
        <p style="color: #4b5563; font-size: 14px; line-height: 1.5;">
          ${
            type === 'register'
              ? 'Thank you for creating an account on Spark. Please enter this 6-digit verification code to complete your registration:'
              : 'You requested a password reset for your Spark account. Use the verification code below to set a new password:'
          }
        </p>
        <div style="background: #ffffff; border: 2px dashed #f43f5e; border-radius: 8px; display: inline-block; padding: 12px 24px; margin: 16px 0;">
          <span style="font-family: monospace; font-size: 32px; font-weight: 800; letter-spacing: 6px; color: #e11d48;">
            ${otp}
          </span>
        </div>
        <p style="color: #9ca3af; font-size: 12px; margin-bottom: 0;">
          This code expires in 10 minutes. If you did not request this, you can safely ignore this email.
        </p>
      </div>

      <div style="text-align: center; border-top: 1px solid #f3f4f6; padding-top: 16px;">
        <p style="color: #9ca3af; font-size: 12px; margin: 0;">&copy; 2026 Spark Dating Inc. All rights reserved.</p>
      </div>
    </div>
  `;

  // Check if real SMTP is configured
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (host && user && pass) {
    try {
      const transporter = nodemailer.createTransport({
        host,
        port: Number(process.env.SMTP_PORT) || 587,
        secure: process.env.SMTP_SECURE === 'true',
        auth: { user, pass },
      });

      await transporter.sendMail({
        from: process.env.EMAIL_FROM || '"Spark Dating" <noreply@sparkdating.app>',
        to: email,
        subject,
        html: htmlContent,
      });

      console.log(`📧 [Nodemailer] Successfully sent OTP email to ${email}`);
      return { success: true };
    } catch (err: any) {
      console.error(`⚠️ [Nodemailer] SMTP send error (${err.message}). Falling back to simulated delivery.`);
    }
  }

  // Local development / testing mode fallback
  console.log(`\n======================================================`);
  console.log(`📬 [SPARK DEV EMAIL SIMULATOR]`);
  console.log(`To: ${email}`);
  console.log(`Type: ${type}`);
  console.log(`Verification OTP: ${otp}`);
  console.log(`======================================================\n`);

  return { success: true, previewCode: otp };
}
