export interface UploadResult {
  url: string;
  publicId?: string;
}

export async function uploadToCloudinary(
  buffer: Buffer,
  mimeType: string,
  folder: string = 'spark_dating_profiles'
): Promise<UploadResult> {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
  const apiKey = process.env.CLOUDINARY_API_KEY;
  const apiSecret = process.env.CLOUDINARY_API_SECRET;

  if (cloudName && apiKey && apiSecret) {
    try {
      // Dynamic import to avoid crash if optional SDK isn't present
      const cloudinary = await import('cloudinary');
      cloudinary.v2.config({
        cloud_name: cloudName,
        api_key: apiKey,
        api_secret: apiSecret,
      });

      return new Promise((resolve, reject) => {
        const uploadStream = cloudinary.v2.uploader.upload_stream(
          {
            folder,
            resource_type: 'image',
            transformation: [{ width: 1000, height: 1250, crop: 'limit', quality: 'auto' }],
          },
          (error, result) => {
            if (error || !result) {
              return reject(error || new Error('Upload failed'));
            }
            resolve({
              url: result.secure_url,
              publicId: result.public_id,
            });
          }
        );
        uploadStream.end(buffer);
      });
    } catch (err: any) {
      console.warn(`[Cloudinary] Upload to cloud failed (${err.message}). Using Data URI fallback.`);
    }
  }

  // Fallback: create base64 Data URI from buffer
  const base64 = buffer.toString('base64');
  const dataUri = `data:${mimeType};base64,${base64}`;
  return {
    url: dataUri,
    publicId: `local_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
  };
}
