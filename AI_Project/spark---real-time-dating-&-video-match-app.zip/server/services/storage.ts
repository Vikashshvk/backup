import bcrypt from 'bcryptjs';
import { isDbConnected } from '../config/db.js';
import { UserModel, IUser } from '../models/User.js';
import { MatchModel, IMatch } from '../models/Match.js';
import { MessageModel, IMessage } from '../models/Message.js';
import { OTPModel, IOTP } from '../models/OTP.js';

export interface UserRecord {
  _id: string;
  name: string;
  email: string;
  passwordHash: string;
  age: number;
  gender: 'male' | 'female' | 'non-binary' | 'other';
  interestedIn: ('male' | 'female' | 'non-binary' | 'everyone')[];
  bio: string;
  photos: string[];
  location: {
    city: string;
    country: string;
    coordinates?: [number, number];
  };
  distanceKm: number;
  interests: string[];
  isVerified: boolean;
  settings: {
    minAge: number;
    maxAge: number;
    maxDistance: number;
    isVisible: boolean;
    soundEnabled: boolean;
  };
  blockedUsers: string[];
  reportedUsers: {
    userId: string;
    reason: string;
    date: Date;
  }[];
  lastActive: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface MatchRecord {
  _id: string;
  users: string[]; // Two user IDs
  likedBy: string[]; // Users who swiped right
  status: 'pending' | 'matched' | 'passed';
  lastInteraction: Date;
  matchedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface MessageRecord {
  _id: string;
  matchId: string;
  sender: string;
  receiver: string;
  content: string;
  mediaUrl?: string;
  read: boolean;
  readAt?: Date;
  createdAt: Date;
}

export interface OtpRecord {
  _id: string;
  email: string;
  otp: string;
  type: 'register' | 'forgot_password';
  expiresAt: Date;
  createdAt: Date;
}

// In-memory persistent data stores (active when standalone MongoDB is not running)
const memoryUsers = new Map<string, UserRecord>();
const memoryMatches = new Map<string, MatchRecord>();
const memoryMessages = new Map<string, MessageRecord>();
const memoryOtps = new Map<string, OtpRecord>();

// Pre-seeded high quality realistic discovery profiles
export const SEED_PROFILES: Omit<UserRecord, '_id' | 'createdAt' | 'updatedAt' | 'lastActive'>[] = [
  {
    name: 'Elena Rostova',
    email: 'elena@example.com',
    passwordHash: bcrypt.hashSync('Password123!', 10),
    age: 26,
    gender: 'female',
    interestedIn: ['everyone'],
    bio: 'Sommelier & culinary explorer 🍷 Can tell you the exact grape variety of your wine. Looking for witty banter, spontaneous road trips to Napa, and sunset views.',
    photos: [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=80',
    ],
    location: { city: 'San Francisco', country: 'USA', coordinates: [-122.4194, 37.7749] },
    distanceKm: 3,
    interests: ['Wine Tasting', 'Fine Dining', 'Art Galleries', 'Tennis', 'Travel', 'Architecture'],
    isVerified: true,
    settings: { minAge: 24, maxAge: 38, maxDistance: 40, isVisible: true, soundEnabled: true },
    blockedUsers: [],
    reportedUsers: [],
  },
  {
    name: 'Marcus Rivera',
    email: 'marcus@example.com',
    passwordHash: bcrypt.hashSync('Password123!', 10),
    age: 29,
    gender: 'male',
    interestedIn: ['female', 'non-binary'],
    bio: 'Architect designing sustainable spaces 🏛️ Vinyl collector, espresso enthusiast, and amateur jazz guitarist. Tell me about your favorite hidden gem in the city.',
    photos: [
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=800&q=80',
    ],
    location: { city: 'San Francisco', country: 'USA', coordinates: [-122.4089, 37.7833] },
    distanceKm: 5,
    interests: ['Architecture', 'Vinyl', 'Espresso', 'Jazz', 'Photography', 'Cycling'],
    isVerified: true,
    settings: { minAge: 23, maxAge: 34, maxDistance: 50, isVisible: true, soundEnabled: true },
    blockedUsers: [],
    reportedUsers: [],
  },
  {
    name: 'Sophie Taylor',
    email: 'sophie@example.com',
    passwordHash: bcrypt.hashSync('Password123!', 10),
    age: 24,
    gender: 'female',
    interestedIn: ['male', 'everyone'],
    bio: 'Product designer & rock climber 🧗‍♀️ Probably at the bouldering gym or hunting for the matcha latte that will change my life. Proud dog mom to Pixel!',
    photos: [
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=800&q=80',
    ],
    location: { city: 'Oakland', country: 'USA', coordinates: [-122.2711, 37.8044] },
    distanceKm: 8,
    interests: ['Bouldering', 'Matcha', 'UI Design', 'Dogs', 'Indie Rock', 'Coffee'],
    isVerified: true,
    settings: { minAge: 22, maxAge: 32, maxDistance: 30, isVisible: true, soundEnabled: true },
    blockedUsers: [],
    reportedUsers: [],
  },
  {
    name: 'Liam Patel',
    email: 'liam@example.com',
    passwordHash: bcrypt.hashSync('Password123!', 10),
    age: 27,
    gender: 'male',
    interestedIn: ['female', 'everyone'],
    bio: 'Sound designer & documentary filmmaker 🎬 Film cameras, night cycling, and deep conversations over street food. Looking for a genuine spark.',
    photos: [
      'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80',
    ],
    location: { city: 'Berkeley', country: 'USA', coordinates: [-122.2585, 37.8719] },
    distanceKm: 12,
    interests: ['Film Making', 'Analog Photography', 'Night Rides', 'Street Food', 'Ambient Music'],
    isVerified: true,
    settings: { minAge: 22, maxAge: 32, maxDistance: 45, isVisible: true, soundEnabled: true },
    blockedUsers: [],
    reportedUsers: [],
  },
  {
    name: 'Chloe Kim',
    email: 'chloe@example.com',
    passwordHash: bcrypt.hashSync('Password123!', 10),
    age: 25,
    gender: 'female',
    interestedIn: ['male', 'female'],
    bio: 'Software engineer building biotech tools & ceramics hobbyist 🏺 When not debugging, I make pottery or cook elaborate Sunday dinners. Let’s make dumplings!',
    photos: [
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80',
    ],
    location: { city: 'San Francisco', country: 'USA', coordinates: [-122.4312, 37.7699] },
    distanceKm: 4,
    interests: ['Ceramics', 'Cooking', 'Biotech', 'Running', 'Board Games', 'Podcasts'],
    isVerified: true,
    settings: { minAge: 23, maxAge: 35, maxDistance: 35, isVisible: true, soundEnabled: true },
    blockedUsers: [],
    reportedUsers: [],
  },
  {
    name: 'Jordan Lee',
    email: 'jordan@example.com',
    passwordHash: bcrypt.hashSync('Password123!', 10),
    age: 28,
    gender: 'non-binary',
    interestedIn: ['everyone'],
    bio: 'Botanist & urban gardener 🌱 Transforming city rooftops into green sanctuaries. Fluent in sarcasm, plant care, and 90s hip-hop.',
    photos: [
      'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=800&q=80',
    ],
    location: { city: 'San Francisco', country: 'USA', coordinates: [-122.4200, 37.7600] },
    distanceKm: 6,
    interests: ['Botany', 'Gardening', 'Hip-Hop', 'Sustainability', 'Thrifting', 'Boba'],
    isVerified: true,
    settings: { minAge: 21, maxAge: 38, maxDistance: 50, isVisible: true, soundEnabled: true },
    blockedUsers: [],
    reportedUsers: [],
  },
];

// Initialize seed data
export function initializeSeedData(): void {
  if (memoryUsers.size === 0) {
    SEED_PROFILES.forEach((profile, index) => {
      const id = `user_seed_${index + 1}`;
      memoryUsers.set(id, {
        ...profile,
        _id: id,
        createdAt: new Date(Date.now() - (index + 1) * 86400000 * 3),
        updatedAt: new Date(),
        lastActive: new Date(Date.now() - index * 1800000), // Recent activity
      });
    });
    console.log(`✨ Initialized ${memoryUsers.size} seed dating profiles for discovery.`);
  }
}

// User Operations
export async function createUser(data: Partial<UserRecord>): Promise<UserRecord> {
  const id = `user_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const newUser: UserRecord = {
    _id: id,
    name: data.name || '',
    email: (data.email || '').toLowerCase().trim(),
    passwordHash: data.passwordHash || '',
    age: Number(data.age) || 21,
    gender: data.gender || 'female',
    interestedIn: data.interestedIn || ['everyone'],
    bio: data.bio || '',
    photos: data.photos && data.photos.length > 0 ? data.photos : [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
    ],
    location: data.location || { city: 'San Francisco', country: 'USA' },
    distanceKm: 1,
    interests: data.interests || ['Coffee', 'Travel', 'Music'],
    isVerified: Boolean(data.isVerified),
    settings: {
      minAge: data.settings?.minAge || 18,
      maxAge: data.settings?.maxAge || 50,
      maxDistance: data.settings?.maxDistance || 50,
      isVisible: data.settings?.isVisible !== false,
      soundEnabled: data.settings?.soundEnabled !== false,
    },
    blockedUsers: [],
    reportedUsers: [],
    lastActive: new Date(),
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  memoryUsers.set(id, newUser);
  return newUser;
}

export async function findUserByEmail(email: string): Promise<UserRecord | null> {
  const normalized = email.toLowerCase().trim();
  for (const user of memoryUsers.values()) {
    if (user.email.toLowerCase() === normalized) {
      return user;
    }
  }
  return null;
}

export async function findUserById(id: string): Promise<UserRecord | null> {
  return memoryUsers.get(id) || null;
}

export async function updateUser(id: string, updates: Partial<UserRecord>): Promise<UserRecord | null> {
  const user = memoryUsers.get(id);
  if (!user) return null;

  const updated: UserRecord = {
    ...user,
    ...updates,
    settings: {
      ...user.settings,
      ...(updates.settings || {}),
    },
    location: {
      ...user.location,
      ...(updates.location || {}),
    },
    updatedAt: new Date(),
  };

  memoryUsers.set(id, updated);
  return updated;
}

export async function deleteUser(id: string): Promise<boolean> {
  const existed = memoryUsers.delete(id);
  if (!existed) return false;

  // Cascading cleanup of matches involving this user
  for (const [matchId, match] of memoryMatches.entries()) {
    if (match.users.includes(id)) {
      memoryMatches.delete(matchId);
      // Delete associated messages
      for (const [msgId, msg] of memoryMessages.entries()) {
        if (msg.matchId === matchId) {
          memoryMessages.delete(msgId);
        }
      }
    }
  }

  // Remove from blocked lists of others
  for (const other of memoryUsers.values()) {
    if (other.blockedUsers.includes(id)) {
      other.blockedUsers = other.blockedUsers.filter((uid) => uid !== id);
    }
  }

  return true;
}

// Discovery Queue Algorithm
export async function getDiscoveryQueue(
  userId: string,
  options?: {
    gender?: string;
    minAge?: number;
    maxAge?: number;
    maxDistance?: number;
  }
): Promise<UserRecord[]> {
  const currentUser = memoryUsers.get(userId);
  if (!currentUser) return [];

  // Find users already swiped or matched by current user
  const swipedUserIds = new Set<string>();
  swipedUserIds.add(userId); // Exclude self

  // Add blocked users
  currentUser.blockedUsers.forEach((id) => swipedUserIds.add(id));

  for (const match of memoryMatches.values()) {
    if (match.users.includes(userId)) {
      // Find other user
      const otherId = match.users.find((id) => id !== userId);
      if (otherId) {
        // If current user already liked or passed, don't show in discovery
        if (match.likedBy.includes(userId) || match.status === 'passed') {
          swipedUserIds.add(otherId);
        }
      }
    }
  }

  const effectiveMinAge = options?.minAge ?? currentUser.settings.minAge;
  const effectiveMaxAge = options?.maxAge ?? currentUser.settings.maxAge;
  const effectiveMaxDist = options?.maxDistance ?? currentUser.settings.maxDistance;
  const targetGender = options?.gender;

  const queue: UserRecord[] = [];

  for (const candidate of memoryUsers.values()) {
    if (swipedUserIds.has(candidate._id)) continue;
    if (!candidate.settings.isVisible) continue;
    if (candidate.blockedUsers.includes(userId)) continue;

    // Age filter
    if (candidate.age < effectiveMinAge || candidate.age > effectiveMaxAge) continue;

    // Distance filter
    if (candidate.distanceKm > effectiveMaxDist) continue;

    // Gender filter
    if (targetGender && targetGender !== 'all' && candidate.gender !== targetGender) continue;

    // Check interestedIn compatibility if not "everyone"
    if (!currentUser.interestedIn.includes('everyone') && !currentUser.interestedIn.includes(candidate.gender as any)) {
      continue;
    }

    queue.push(candidate);
  }

  return queue;
}

// Swiping & Matching Logic
export async function recordSwipe(
  userId: string,
  targetUserId: string,
  action: 'like' | 'pass' | 'superlike'
): Promise<{ isMatch: boolean; match?: MatchRecord; targetUser: UserRecord }> {
  const targetUser = memoryUsers.get(targetUserId);
  if (!targetUser) {
    throw new Error('Target user does not exist');
  }

  // Find existing match record between both users
  let match: MatchRecord | undefined;
  for (const m of memoryMatches.values()) {
    if (m.users.includes(userId) && m.users.includes(targetUserId)) {
      match = m;
      break;
    }
  }

  if (action === 'pass') {
    if (!match) {
      const matchId = `match_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      match = {
        _id: matchId,
        users: [userId, targetUserId],
        likedBy: [],
        status: 'passed',
        lastInteraction: new Date(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      memoryMatches.set(matchId, match);
    } else {
      match.status = 'passed';
      match.updatedAt = new Date();
    }
    return { isMatch: false, match, targetUser };
  }

  // Action is 'like' or 'superlike'
  if (!match) {
    // Check if target user is one of the seed profiles. For seed profiles,
    // let's create high match probability so the user experiences the delight of matching!
    const isSeedProfile = targetUserId.startsWith('user_seed_');
    const matchId = `match_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    // In a dating app demo, seed users love swiping right back!
    const seedWillMatch = isSeedProfile;
    const likedBy = seedWillMatch ? [userId, targetUserId] : [userId];
    const isMatch = seedWillMatch;

    match = {
      _id: matchId,
      users: [userId, targetUserId],
      likedBy,
      status: isMatch ? 'matched' : 'pending',
      matchedAt: isMatch ? new Date() : undefined,
      lastInteraction: new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    memoryMatches.set(matchId, match);

    // If matched with seed user, create initial welcoming icebreaker message
    if (isMatch) {
      const welcomeMessages = [
        `Hey there! Love your profile 😊 How is your week going?`,
        `Hi! Saw your interests—we definitely have a lot in common! ✨`,
        `Hey! Couldn't resist saying hi. What's your favorite spot in town? ☕`,
      ];
      const randomMsg = welcomeMessages[Math.floor(Math.random() * welcomeMessages.length)];
      setTimeout(async () => {
        await createMessage(match!._id, targetUserId, userId, randomMsg);
      }, 1200);
    }

    return { isMatch, match, targetUser };
  } else {
    // Match record already exists
    if (!match.likedBy.includes(userId)) {
      match.likedBy.push(userId);
    }

    // Mutual like check
    const otherLiked = match.likedBy.includes(targetUserId);
    if (otherLiked && match.status !== 'matched') {
      match.status = 'matched';
      match.matchedAt = new Date();
      match.updatedAt = new Date();
      return { isMatch: true, match, targetUser };
    }

    return { isMatch: match.status === 'matched', match, targetUser };
  }
}

// Get User's Matches
export async function getUserMatches(userId: string): Promise<
  Array<{
    match: MatchRecord;
    partner: UserRecord;
    lastMessage?: MessageRecord;
    unreadCount: number;
  }>
> {
  const result: Array<{
    match: MatchRecord;
    partner: UserRecord;
    lastMessage?: MessageRecord;
    unreadCount: number;
  }> = [];

  for (const match of memoryMatches.values()) {
    if (match.status === 'matched' && match.users.includes(userId)) {
      const partnerId = match.users.find((id) => id !== userId);
      if (!partnerId) continue;

      const partner = memoryUsers.get(partnerId);
      if (!partner) continue;

      // Find last message and unread count
      let lastMsg: MessageRecord | undefined;
      let unread = 0;

      for (const msg of memoryMessages.values()) {
        if (msg.matchId === match._id) {
          if (!lastMsg || msg.createdAt.getTime() > lastMsg.createdAt.getTime()) {
            lastMsg = msg;
          }
          if (msg.receiver === userId && !msg.read) {
            unread++;
          }
        }
      }

      result.push({
        match,
        partner,
        lastMessage: lastMsg,
        unreadCount: unread,
      });
    }
  }

  // Sort by latest interaction
  result.sort((a, b) => {
    const timeA = a.lastMessage?.createdAt.getTime() || a.match.matchedAt?.getTime() || 0;
    const timeB = b.lastMessage?.createdAt.getTime() || b.match.matchedAt?.getTime() || 0;
    return timeB - timeA;
  });

  return result;
}

// Chat Messages
export async function getMessages(matchId: string): Promise<MessageRecord[]> {
  const list: MessageRecord[] = [];
  for (const msg of memoryMessages.values()) {
    if (msg.matchId === matchId) {
      list.push(msg);
    }
  }
  list.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  return list;
}

export async function createMessage(
  matchId: string,
  sender: string,
  receiver: string,
  content: string,
  mediaUrl?: string
): Promise<MessageRecord> {
  const id = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const message: MessageRecord = {
    _id: id,
    matchId,
    sender,
    receiver,
    content,
    mediaUrl,
    read: false,
    createdAt: new Date(),
  };

  memoryMessages.set(id, message);

  // Update match lastInteraction
  const match = memoryMatches.get(matchId);
  if (match) {
    match.lastInteraction = new Date();
    match.updatedAt = new Date();
  }

  return message;
}

export async function markMessagesAsRead(matchId: string, readerUserId: string): Promise<void> {
  for (const msg of memoryMessages.values()) {
    if (msg.matchId === matchId && msg.receiver === readerUserId && !msg.read) {
      msg.read = true;
      msg.readAt = new Date();
    }
  }
}

// OTP Operations
export async function createOtp(email: string, type: 'register' | 'forgot_password'): Promise<string> {
  const normalized = email.toLowerCase().trim();
  // 6-digit numeric OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

  const id = `otp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  memoryOtps.set(id, {
    _id: id,
    email: normalized,
    otp,
    type,
    expiresAt,
    createdAt: new Date(),
  });

  return otp;
}

export async function verifyOtp(email: string, otp: string, type: 'register' | 'forgot_password'): Promise<boolean> {
  const normalized = email.toLowerCase().trim();
  for (const [id, record] of memoryOtps.entries()) {
    if (record.email === normalized && record.otp === otp.trim() && record.type === type) {
      if (record.expiresAt.getTime() > Date.now()) {
        memoryOtps.delete(id); // Consume OTP once verified
        return true;
      }
    }
  }
  return false;
}

// Initialize seed data immediately
initializeSeedData();
