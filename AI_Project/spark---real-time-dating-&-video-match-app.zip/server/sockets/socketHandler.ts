import { Server as SocketIOServer, Socket } from 'socket.io';
import { Server as HTTPServer } from 'http';
import jwt from 'jsonwebtoken';
import { findUserById, updateUser } from '../services/storage.js';

let ioInstance: SocketIOServer | null = null;

// Track active connected users: userId -> Set of socketIds
const onlineUsersMap = new Map<string, Set<string>>();
// Track socketId -> userId
const socketToUserMap = new Map<string, string>();

const JWT_SECRET = process.env.JWT_SECRET || 'spark_jwt_secret_super_secure_key_change_in_production_2026';

export function initializeSocket(httpServer: HTTPServer): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST'],
      credentials: true,
    },
  });

  ioInstance = io;

  io.use(async (socket: Socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.replace('Bearer ', '');
      if (token) {
        try {
          const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
          socket.data.userId = decoded.userId;
        } catch (e) {
          // Token invalid, still allow connection with guest/anonymous id for dev preview
        }
      }
      next();
    } catch (err) {
      next();
    }
  });

  io.on('connection', (socket: Socket) => {
    // Client can explicitly register their userId
    socket.on('register_user', (userId: string) => {
      if (!userId) return;
      socket.data.userId = userId;
      socketToUserMap.set(socket.id, userId);

      let sockets = onlineUsersMap.get(userId);
      if (!sockets) {
        sockets = new Set();
        onlineUsersMap.set(userId, sockets);
      }
      sockets.add(socket.id);

      // Join personal room for private notifications
      socket.join(`user:${userId}`);

      // Broadcast online status
      io.emit('user_online', { userId, timestamp: new Date() });
      updateUser(userId, { lastActive: new Date() }).catch(() => {});

      // Send list of currently online users to the newly connected socket
      const onlineIds = Array.from(onlineUsersMap.keys());
      // Also make seed users appear online
      onlineIds.push('user_seed_1', 'user_seed_2', 'user_seed_3', 'user_seed_4', 'user_seed_5');
      socket.emit('online_users_list', onlineIds);
    });

    // Match Room management
    socket.on('join_match_room', (matchId: string) => {
      if (!matchId) return;
      socket.join(`match:${matchId}`);
    });

    socket.on('leave_match_room', (matchId: string) => {
      if (!matchId) return;
      socket.leave(`match:${matchId}`);
    });

    // Typing indicators
    socket.on('typing_start', (data: { matchId: string; userId: string }) => {
      if (!data?.matchId) return;
      socket.to(`match:${data.matchId}`).emit('user_typing', {
        matchId: data.matchId,
        userId: data.userId || socket.data.userId,
        isTyping: true,
      });
    });

    socket.on('typing_stop', (data: { matchId: string; userId: string }) => {
      if (!data?.matchId) return;
      socket.to(`match:${data.matchId}`).emit('user_typing', {
        matchId: data.matchId,
        userId: data.userId || socket.data.userId,
        isTyping: false,
      });
    });

    // ==========================================
    // WebRTC 1-on-1 Video Calling Signaling
    // ==========================================

    // Caller calls callee
    socket.on(
      'call_user',
      async (data: {
        userToCall: string;
        signalData: any;
        from: string;
        name: string;
        callerPhoto?: string;
      }) => {
        const { userToCall, signalData, from, name, callerPhoto } = data;

        // Check if calling a demo seed companion
        if (userToCall.startsWith('user_seed_')) {
          const companion = await findUserById(userToCall);
          // Simulate companion answering after 1.8 seconds!
          setTimeout(() => {
            socket.emit('call_accepted', {
              signal: { type: 'answer', sdp: 'simulated_remote_sdp_offer' },
              calleeName: companion?.name || 'Match',
              calleePhoto: companion?.photos?.[0],
              isSimulated: true,
            });
          }, 1800);
          return;
        }

        // Real peer forwarding to user room
        io.to(`user:${userToCall}`).emit('incoming_call', {
          signal: signalData,
          from,
          name,
          callerPhoto,
        });
      }
    );

    // Callee answers caller
    socket.on('answer_call', (data: { signal: any; to: string }) => {
      io.to(`user:${data.to}`).emit('call_accepted', {
        signal: data.signal,
      });
    });

    // Exchange ICE candidate
    socket.on('ice_candidate', (data: { to: string; candidate: any }) => {
      if (data?.to) {
        io.to(`user:${data.to}`).emit('ice_candidate', {
          candidate: data.candidate,
          from: socket.data.userId,
        });
      }
    });

    // End / Hangup call
    socket.on('end_call', (data: { to: string }) => {
      if (data?.to) {
        io.to(`user:${data.to}`).emit('call_ended', {
          from: socket.data.userId,
        });
      }
    });

    // Call declined / busy
    socket.on('decline_call', (data: { to: string; reason?: string }) => {
      if (data?.to) {
        io.to(`user:${data.to}`).emit('call_declined', {
          from: socket.data.userId,
          reason: data.reason || 'declined',
        });
      }
    });

    // Disconnect cleanup
    socket.on('disconnect', () => {
      const userId = socketToUserMap.get(socket.id) || socket.data.userId;
      if (userId) {
        socketToUserMap.delete(socket.id);
        const sockets = onlineUsersMap.get(userId);
        if (sockets) {
          sockets.delete(socket.id);
          if (sockets.size === 0) {
            onlineUsersMap.delete(userId);
            io.emit('user_offline', { userId, timestamp: new Date() });
            updateUser(userId, { lastActive: new Date() }).catch(() => {});
          }
        }
      }
    });
  });

  return io;
}

export function getIO(): SocketIOServer | null {
  return ioInstance;
}

export function isUserOnline(userId: string): boolean {
  if (userId.startsWith('user_seed_')) return true; // Seed companions online
  return onlineUsersMap.has(userId) && (onlineUsersMap.get(userId)?.size || 0) > 0;
}
