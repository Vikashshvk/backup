import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth.js';
import {
  getDiscoveryQueue,
  recordSwipe,
  getUserMatches,
} from '../services/storage.js';
import { getIO } from '../sockets/socketHandler.js';

export async function getDiscovery(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { gender, minAge, maxAge, maxDistance } = req.query;

    const queue = await getDiscoveryQueue(req.user._id, {
      gender: gender as string,
      minAge: minAge ? Number(minAge) : undefined,
      maxAge: maxAge ? Number(maxAge) : undefined,
      maxDistance: maxDistance ? Number(maxDistance) : undefined,
    });

    const safeQueue = queue.map((u) => {
      const { passwordHash, settings, blockedUsers, reportedUsers, ...rest } = u;
      return rest;
    });

    res.json({ success: true, count: safeQueue.length, candidates: safeQueue });
  } catch (err: any) {
    console.error('Get discovery error:', err);
    res.status(500).json({ success: false, message: 'Failed to load discovery queue' });
  }
}

export async function handleSwipe(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { targetUserId, action } = req.body;
    if (!targetUserId || !['like', 'pass', 'superlike'].includes(action)) {
      res.status(400).json({ success: false, message: 'Valid targetUserId and action (like/pass/superlike) are required' });
      return;
    }

    const result = await recordSwipe(req.user._id, targetUserId, action);

    // If it's a mutual match, emit real-time event to both users if connected
    if (result.isMatch && result.match) {
      try {
        const io = getIO();
        if (io) {
          io.to(`user:${targetUserId}`).emit('new_match', {
            matchId: result.match._id,
            partner: {
              _id: req.user._id,
              name: req.user.name,
              photos: req.user.photos,
              age: req.user.age,
              bio: req.user.bio,
            },
          });
        }
      } catch (e) {
        // Socket emit failure shouldn't fail HTTP request
      }
    }

    const { passwordHash, ...safePartner } = result.targetUser;

    res.json({
      success: true,
      isMatch: result.isMatch,
      match: result.match,
      partner: safePartner,
    });
  } catch (err: any) {
    console.error('Handle swipe error:', err);
    res.status(500).json({ success: false, message: 'Failed to process swipe' });
  }
}

export async function getMatchesList(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const matches = await getUserMatches(req.user._id);

    const safeMatches = matches.map((m) => {
      const { passwordHash, blockedUsers, reportedUsers, ...safePartner } = m.partner;
      return {
        matchId: m.match._id,
        matchedAt: m.match.matchedAt,
        lastInteraction: m.match.lastInteraction,
        partner: safePartner,
        lastMessage: m.lastMessage,
        unreadCount: m.unreadCount,
      };
    });

    res.json({ success: true, count: safeMatches.length, matches: safeMatches });
  } catch (err: any) {
    console.error('Get matches error:', err);
    res.status(500).json({ success: false, message: 'Failed to retrieve matches' });
  }
}
