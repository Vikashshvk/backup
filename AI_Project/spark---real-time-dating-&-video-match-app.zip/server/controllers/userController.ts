import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth.js';
import {
  updateUser,
  deleteUser,
  findUserById,
} from '../services/storage.js';
import { uploadToCloudinary } from '../services/cloudinaryService.js';

export function calculateCompletionMeter(user: any): number {
  let score = 0;
  if (user.name) score += 15;
  if (user.bio && user.bio.length >= 20) score += 20;
  if (user.photos && user.photos.length >= 1) score += 20;
  if (user.photos && user.photos.length >= 3) score += 10;
  if (user.interests && user.interests.length >= 3) score += 15;
  if (user.age >= 18) score += 10;
  if (user.isVerified) score += 10;
  return Math.min(100, score);
}

export async function getProfile(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }
    const { passwordHash, ...safeUser } = req.user;
    const completionPercentage = calculateCompletionMeter(safeUser);
    res.json({ success: true, user: safeUser, completionPercentage });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to get profile' });
  }
}

export async function updateProfile(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { name, bio, interests, age, gender, interestedIn, location } = req.body;
    const updates: any = {};

    if (name) updates.name = name.trim();
    if (bio !== undefined) updates.bio = bio.trim();
    if (Array.isArray(interests)) updates.interests = interests;
    if (age) {
      const numAge = Number(age);
      if (numAge >= 18) updates.age = numAge;
    }
    if (gender) updates.gender = gender;
    if (interestedIn) updates.interestedIn = Array.isArray(interestedIn) ? interestedIn : [interestedIn];
    if (location) updates.location = location;

    const updatedUser = await updateUser(req.user._id, updates);
    if (!updatedUser) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    const { passwordHash, ...safeUser } = updatedUser;
    const completionPercentage = calculateCompletionMeter(safeUser);

    res.json({
      success: true,
      message: 'Profile updated successfully',
      user: safeUser,
      completionPercentage,
    });
  } catch (err: any) {
    console.error('Update profile error:', err);
    res.status(500).json({ success: false, message: 'Failed to update profile' });
  }
}

export async function uploadPhoto(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    if (!req.file) {
      res.status(400).json({ success: false, message: 'Please select an image file to upload' });
      return;
    }

    // Upload to Cloudinary pipeline or Data URI
    const uploadResult = await uploadToCloudinary(
      req.file.buffer,
      req.file.mimetype,
      `spark_users/${req.user._id}`
    );

    const existingPhotos = req.user.photos || [];
    const updatedPhotos = [...existingPhotos, uploadResult.url];

    const updatedUser = await updateUser(req.user._id, { photos: updatedPhotos });
    if (!updatedUser) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    const { passwordHash, ...safeUser } = updatedUser;
    const completionPercentage = calculateCompletionMeter(safeUser);

    res.json({
      success: true,
      message: 'Photo uploaded successfully',
      photoUrl: uploadResult.url,
      user: safeUser,
      completionPercentage,
    });
  } catch (err: any) {
    console.error('Upload photo error:', err);
    res.status(500).json({ success: false, message: 'Failed to upload photo' });
  }
}

export async function deletePhoto(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { photoUrl } = req.body;
    if (!photoUrl) {
      res.status(400).json({ success: false, message: 'Photo URL is required' });
      return;
    }

    const updatedPhotos = (req.user.photos || []).filter((p) => p !== photoUrl);
    const updatedUser = await updateUser(req.user._id, { photos: updatedPhotos });

    if (!updatedUser) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    const { passwordHash, ...safeUser } = updatedUser;
    const completionPercentage = calculateCompletionMeter(safeUser);

    res.json({
      success: true,
      message: 'Photo removed',
      user: safeUser,
      completionPercentage,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to delete photo' });
  }
}

export async function updateSettings(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { minAge, maxAge, maxDistance, isVisible, soundEnabled } = req.body;
    const newSettings = {
      ...req.user.settings,
      ...(minAge !== undefined && { minAge: Number(minAge) }),
      ...(maxAge !== undefined && { maxAge: Number(maxAge) }),
      ...(maxDistance !== undefined && { maxDistance: Number(maxDistance) }),
      ...(isVisible !== undefined && { isVisible: Boolean(isVisible) }),
      ...(soundEnabled !== undefined && { soundEnabled: Boolean(soundEnabled) }),
    };

    const updatedUser = await updateUser(req.user._id, { settings: newSettings });
    if (!updatedUser) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    const { passwordHash, ...safeUser } = updatedUser;
    res.json({ success: true, message: 'Settings saved', user: safeUser });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to update settings' });
  }
}

export async function blockUser(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { targetUserId } = req.body;
    if (!targetUserId) {
      res.status(400).json({ success: false, message: 'Target user ID is required' });
      return;
    }

    const blocked = new Set(req.user.blockedUsers || []);
    blocked.add(targetUserId);

    const updatedUser = await updateUser(req.user._id, { blockedUsers: Array.from(blocked) });
    res.json({ success: true, message: 'User blocked successfully' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to block user' });
  }
}

export async function reportUser(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { targetUserId, reason } = req.body;
    if (!targetUserId || !reason) {
      res.status(400).json({ success: false, message: 'Target user ID and reason are required' });
      return;
    }

    const reportedList = req.user.reportedUsers || [];
    reportedList.push({
      userId: targetUserId,
      reason: reason.trim(),
      date: new Date(),
    });

    // Also auto block reported user for safety
    const blocked = new Set(req.user.blockedUsers || []);
    blocked.add(targetUserId);

    await updateUser(req.user._id, {
      reportedUsers: reportedList,
      blockedUsers: Array.from(blocked),
    });

    res.json({ success: true, message: 'Thank you for reporting. Our safety team will review this.' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to report user' });
  }
}

export async function deleteAccount(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    await deleteUser(req.user._id);
    res.clearCookie('token');
    res.json({ success: true, message: 'Your Spark account and data have been permanently deleted.' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to delete account' });
  }
}
