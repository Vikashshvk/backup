import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth.js';
import {
  getMessages,
  createMessage,
  markMessagesAsRead,
  findUserById,
} from '../services/storage.js';
import { getIO } from '../sockets/socketHandler.js';

export async function getMatchMessages(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { matchId } = req.params;
    if (!matchId) {
      res.status(400).json({ success: false, message: 'Match ID is required' });
      return;
    }

    // Auto mark received messages as read
    await markMessagesAsRead(matchId, req.user._id);

    const messages = await getMessages(matchId);
    res.json({ success: true, messages });
  } catch (err: any) {
    console.error('Get messages error:', err);
    res.status(500).json({ success: false, message: 'Failed to retrieve messages' });
  }
}

export async function sendMessage(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { matchId } = req.params;
    const { receiverId, content, mediaUrl } = req.body;

    if (!matchId || !receiverId) {
      res.status(400).json({ success: false, message: 'Match ID and Receiver ID are required' });
      return;
    }

    if (!content && !mediaUrl) {
      res.status(400).json({ success: false, message: 'Message must have content or an image' });
      return;
    }

    const newMsg = await createMessage(
      matchId,
      req.user._id,
      receiverId,
      content ? content.trim() : '',
      mediaUrl
    );

    // Real-time broadcast via Socket.io
    const io = getIO();
    if (io) {
      io.to(`match:${matchId}`).emit('receive_message', newMsg);
      io.to(`user:${receiverId}`).emit('unread_message_notification', {
        matchId,
        senderId: req.user._id,
        senderName: req.user.name,
        message: newMsg,
      });
    }

    // Interactive Demo Simulation: If chatting with a seed user (e.g. user_seed_1),
    // simulate a smart, charming dating companion response after 1.8s
    if (receiverId.startsWith('user_seed_')) {
      const partner = await findUserById(receiverId);
      const partnerName = partner?.name || 'Your match';

      setTimeout(async () => {
        const smartReplies = [
          `That sounds amazing! I love that about you 😊`,
          `Totally agree! We definitely need to check that out together sometime.`,
          `Haha you're hilarious! Are you free for a coffee or wine this weekend? ☕🍷`,
          `Tell me more! I'm genuinely curious.`,
          `That just made my day! What are you up to right now? ✨`,
        ];
        const replyText = smartReplies[Math.floor(Math.random() * smartReplies.length)];

        // Simulate typing indicator first
        if (io) {
          io.to(`match:${matchId}`).emit('user_typing', {
            matchId,
            userId: receiverId,
            isTyping: true,
          });
        }

        setTimeout(async () => {
          if (io) {
            io.to(`match:${matchId}`).emit('user_typing', {
              matchId,
              userId: receiverId,
              isTyping: false,
            });
          }

          const botMsg = await createMessage(matchId, receiverId, req.user!._id, replyText);

          if (io) {
            io.to(`match:${matchId}`).emit('receive_message', botMsg);
            io.to(`user:${req.user!._id}`).emit('unread_message_notification', {
              matchId,
              senderId: receiverId,
              senderName: partnerName,
              message: botMsg,
            });
          }
        }, 1200);
      }, 1500);
    }

    res.status(201).json({ success: true, message: newMsg });
  } catch (err: any) {
    console.error('Send message error:', err);
    res.status(500).json({ success: false, message: 'Failed to send message' });
  }
}

export async function markAsRead(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const { matchId } = req.params;
    await markMessagesAsRead(matchId, req.user._id);

    const io = getIO();
    if (io) {
      io.to(`match:${matchId}`).emit('messages_read', {
        matchId,
        readerId: req.user._id,
        readAt: new Date(),
      });
    }

    res.json({ success: true, message: 'Messages marked as read' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to mark messages as read' });
  }
}
