import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import {
  createUser,
  findUserByEmail,
  findUserById,
  updateUser,
  createOtp,
  verifyOtp,
} from '../services/storage.js';
import { generateToken, AuthenticatedRequest } from '../middleware/auth.js';
import { sendOtpEmail, getLatestDevOtp } from '../services/emailService.js';

export async function register(req: Request, res: Response): Promise<void> {
  try {
    const { name, email, password, age, gender, interestedIn, bio } = req.body;

    if (!name || !email || !password || !age) {
      res.status(400).json({ success: false, message: 'Please provide all required fields (name, email, password, age).' });
      return;
    }

    const numericAge = Number(age);
    if (isNaN(numericAge) || numericAge < 18) {
      res.status(400).json({ success: false, message: 'You must be at least 18 years old to join Spark.' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
      return;
    }

    const existing = await findUserByEmail(email);
    if (existing) {
      res.status(400).json({ success: false, message: 'An account with this email address already exists.' });
      return;
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const newUser = await createUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      passwordHash,
      age: numericAge,
      gender: gender || 'female',
      interestedIn: Array.isArray(interestedIn) ? interestedIn : [interestedIn || 'everyone'],
      bio: bio ? bio.trim() : '',
      isVerified: false,
    });

    // Generate 6-digit OTP
    const otp = await createOtp(newUser.email, 'register');
    const emailResult = await sendOtpEmail({
      email: newUser.email,
      name: newUser.name,
      otp,
      type: 'register',
    });

    res.status(201).json({
      success: true,
      message: 'Registration initiated. Verification OTP sent to your email.',
      email: newUser.email,
      userId: newUser._id,
      previewOtp: emailResult.previewCode,
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    res.status(500).json({ success: false, message: 'Internal server error during registration.' });
  }
}

export async function sendOtp(req: Request, res: Response): Promise<void> {
  try {
    const { email, type = 'register' } = req.body;
    if (!email) {
      res.status(400).json({ success: false, message: 'Email is required.' });
      return;
    }

    const user = await findUserByEmail(email);
    if (type === 'forgot_password' && !user) {
      res.status(404).json({ success: false, message: 'No account found with this email address.' });
      return;
    }

    const otp = await createOtp(email, type as any);
    const emailResult = await sendOtpEmail({
      email,
      name: user?.name || 'there',
      otp,
      type: type as any,
    });

    res.json({
      success: true,
      message: 'Verification OTP sent successfully.',
      previewOtp: emailResult.previewCode,
    });
  } catch (err: any) {
    console.error('Send OTP error:', err);
    res.status(500).json({ success: false, message: 'Failed to send OTP.' });
  }
}

export async function verifyOtpHandler(req: Request, res: Response): Promise<void> {
  try {
    const { email, otp, type = 'register' } = req.body;
    if (!email || !otp) {
      res.status(400).json({ success: false, message: 'Email and OTP code are required.' });
      return;
    }

    const isValid = await verifyOtp(email, otp, type as any);
    if (!isValid) {
      res.status(400).json({ success: false, message: 'Invalid or expired OTP code. Please try again.' });
      return;
    }

    const user = await findUserByEmail(email);
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found.' });
      return;
    }

    if (type === 'register') {
      await updateUser(user._id, { isVerified: true });
      user.isVerified = true;
    }

    const token = generateToken(user._id);

    // Set secure cookie
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    // Strip passwordHash from response
    const { passwordHash, ...safeUser } = user;

    res.json({
      success: true,
      message: 'Email successfully verified!',
      token,
      user: safeUser,
    });
  } catch (err: any) {
    console.error('Verify OTP error:', err);
    res.status(500).json({ success: false, message: 'Failed to verify OTP.' });
  }
}

export async function login(req: Request, res: Response): Promise<void> {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ success: false, message: 'Please provide both email and password.' });
      return;
    }

    const user = await findUserByEmail(email);
    if (!user) {
      res.status(401).json({ success: false, message: 'Invalid email or password.' });
      return;
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      res.status(401).json({ success: false, message: 'Invalid email or password.' });
      return;
    }

    if (!user.isVerified) {
      // Prompt user to verify email
      const otp = await createOtp(user.email, 'register');
      const emailResult = await sendOtpEmail({
        email: user.email,
        name: user.name,
        otp,
        type: 'register',
      });

      res.status(403).json({
        success: false,
        requiresVerification: true,
        message: 'Please verify your email address to log in. A new OTP has been sent.',
        email: user.email,
        previewOtp: emailResult.previewCode,
      });
      return;
    }

    const token = generateToken(user._id);

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    const { passwordHash, ...safeUser } = user;

    res.json({
      success: true,
      message: 'Logged in successfully.',
      token,
      user: safeUser,
    });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Failed to log in.' });
  }
}

export async function forgotPassword(req: Request, res: Response): Promise<void> {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ success: false, message: 'Email address is required.' });
      return;
    }

    const user = await findUserByEmail(email);
    if (!user) {
      // Don't leak user existence in production, but provide helpful feedback
      res.json({
        success: true,
        message: 'If an account exists with this email, a password reset code has been sent.',
      });
      return;
    }

    const otp = await createOtp(email, 'forgot_password');
    const emailResult = await sendOtpEmail({
      email,
      name: user.name,
      otp,
      type: 'forgot_password',
    });

    res.json({
      success: true,
      message: 'Password reset code sent to your email.',
      previewOtp: emailResult.previewCode,
    });
  } catch (err: any) {
    console.error('Forgot password error:', err);
    res.status(500).json({ success: false, message: 'Failed to send password reset code.' });
  }
}

export async function resetPassword(req: Request, res: Response): Promise<void> {
  try {
    const { email, otp, newPassword } = req.body;
    if (!email || !otp || !newPassword) {
      res.status(400).json({ success: false, message: 'Email, OTP, and new password are required.' });
      return;
    }

    if (newPassword.length < 6) {
      res.status(400).json({ success: false, message: 'New password must be at least 6 characters long.' });
      return;
    }

    const isValid = await verifyOtp(email, otp, 'forgot_password');
    if (!isValid) {
      res.status(400).json({ success: false, message: 'Invalid or expired OTP code.' });
      return;
    }

    const user = await findUserByEmail(email);
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found.' });
      return;
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(newPassword, salt);
    await updateUser(user._id, { passwordHash });

    res.json({
      success: true,
      message: 'Password reset successful! You can now log in with your new password.',
    });
  } catch (err: any) {
    console.error('Reset password error:', err);
    res.status(500).json({ success: false, message: 'Failed to reset password.' });
  }
}

export async function demoLogin(req: Request, res: Response): Promise<void> {
  try {
    // Look for or create demo user "Alex Chen"
    let user = await findUserByEmail('alex.chen@example.com');
    if (!user) {
      user = await createUser({
        name: 'Alex Chen',
        email: 'alex.chen@example.com',
        passwordHash: await bcrypt.hash('DemoSpark2026!', 10),
        age: 25,
        gender: 'female',
        interestedIn: ['everyone'],
        bio: 'Product Designer in SF ☕ Weekend hiker, film photography lover & ramen aficionado. Looking for good vibes and genuine connection.',
        photos: [
          'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
        ],
        location: { city: 'San Francisco', country: 'USA' },
        interests: ['Design', 'Coffee', 'Hiking', 'Film Photography', 'Ramen', 'Indie Music'],
        isVerified: true,
      });
    }

    const token = generateToken(user._id);
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    const { passwordHash, ...safeUser } = user;
    res.json({
      success: true,
      message: 'Demo login successful as Alex Chen.',
      token,
      user: safeUser,
    });
  } catch (err: any) {
    console.error('Demo login error:', err);
    res.status(500).json({ success: false, message: 'Failed to demo login.' });
  }
}

export async function getMe(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Not authenticated.' });
      return;
    }
    const { passwordHash, ...safeUser } = req.user;
    res.json({ success: true, user: safeUser });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to retrieve user profile.' });
  }
}

export async function logout(_req: Request, res: Response): Promise<void> {
  res.clearCookie('token');
  res.json({ success: true, message: 'Logged out successfully.' });
}
